<?php
require_once "../load.php";
\Fr\LS::init();
?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<title>Home | zikafund - Keep the money flowing...</title>          		  		  
  </head>
  <body>
    <?php include "$docRoot/inc/header.php";?>
      <div class="icontent" style=" margin-top:70px;">
          <?php
		  		//Check if user has a flagged order
			  $sql = $OP->dbh->prepare("SELECT * FROM `transactions` WHERE `statusID`='8' AND (`rID`=? OR `sID`=?)");
			  $sql->execute(array($who,$who));
			  $flaggedTRANS = $sql->rowCount();
			  $t = $sql->fetch();
			  if ($flaggedTRANS > 0){
				 $tID = $t['id'];
				 $rID = $t['rID'];
			  	 $sID = $t['sID'];
			  	 $soID = $t['soID'];
			  	 $roID = $t['roID'];
			  	 $amount = $t['amount'];
				 if ($rID == $who){
					 $tt1 = "<h3>You Reported ".get("name",$sID,false)." For Uploading Fake Proof Of Payment On Order: 
					 ".$tID." Worth N".$amount."</h3>";
					 }else{
						 $tt1 = "<h3>".get("name",$rID,false)." Reported You For Uploading Fake Proof Of Payment On Order:
						  ".$tID." Worth N".$amount."</h3>";
						 }
					 $tt2 = "Please Be Patient";
					 $tt3 = "<h3>We will resolve this within 24hrs. You can continue with your normal transactions. 
					 Thanks for your trust in us.</h3>";
				 ?>
				 	<div class="icontent" style="background:white;margin-top:70px;">
						<center><div class="heading text-center" style="color:green;">
							 <?php echo $tt1; ?>
						</div>
      						<p class="lead">
         					 <?php echo $tt2; ?>
     						</p>
    					<div class="heading text-center" style="color:green;">
							 <?php echo $tt3; ?>
						</div>
   						</center>	
					</div> 
				<?php  }
				
				//Check if user has an active package
				/********Not working for a multiple position********/
			  $sql = $OP->dbh->prepare("SELECT * FROM `activations` WHERE `statusID`<'6' AND `uid`=?");
			  $sql->execute(array($who));
			  $activePK = $sql->rowCount();
			  $r = $sql->fetch();
			  $oID = $r['id'];
	 		  $statusID = $r['statusID'];
			  
			  if ($activePK > 0){
			  //Return the transaction details
			  if ($statusID == 1 || $statusID == 2){$crt = 'soID';}else{$crt = 'roID';}
			  $sql = $OP->dbh->prepare("SELECT * FROM `transactions` WHERE `statusID`<'5' AND `{$crt}`=?");
			  $sql->execute(array($oID));
			  $activeTRANS = $sql->rowCount();
			  
			  if ($activeTRANS > 0){
			  for ($i= 0; $i < $activeTRANS; $i++){
			  $t = $sql->fetch();
			  $tID = $t['id'];
			  $tStatusID = $t['statusID'];
			  $rID = $t['rID'];
			  $sID = $t['sID'];
			  $soID = $t['soID'];
			  $amount = $t['amount'];
			  $timeVal = strtotime($t['ending']) - strtotime(date('Y-m-d H:i:s'));
			  }
			  
			  
			  //Return Senders / Recievers details
			  if ($statusID == 1 || $statusID == 2){$id = $rID;}else{$id = $sID;}
			  		if(!class_exists("Ec")){
             			 require_once "$docRoot/inc/class.ecoin.php";
            		}       	
					/*Credit user*/
					$HRep = new Ec();
					$details = $HRep->getDetails($id);
					$uname = $details['uName'];
					$uphone = $details['uPhone'];
					$uemail = $details['email'];
					$ubank = $details['bName'];
					$uAccNo = $details['accNo'];
					$uAccName = $details['accName'];
					$timeDiff = $HRep->gettimeDiff($timeVal);
			  }/*Get users last order closed time*/
			  }else{
				 	$sql = $OP->dbh->prepare(
						"SELECT * FROM `activations` WHERE `statusID`>'5' AND `uid`=? ORDER BY `id` DESC LIMIT 1");
			  		$sql->execute(array($who));
			  		$r = $sql->fetch();
	 		  		$cTime = $r['closed'];
					$timeVal =  date($r['closed'],strtotime('+48 hours')) - strtotime(date('Y-m-d H:i:s'));
				  }
		
			  include "$docRoot/inc/packages.php";
			  
			  
          ?>
    </div>
    <?php 
	include "$docRoot/inc/sidemenu.php";
    include "$docRoot/inc/scripts.php";
	?>
<script>
var w = '<?php echo HOST ?>';
var m = '<?php echo $timeVal; ?>';
var q = '<?php echo $tStatusID; ?>';
var p = "You can not purge a transaction untill the alloted time elapse. Please wait patiently";
var r = "You marked this transaction as paid. You can not decline anymore";
$(function(){
	setInterval(timeDiff,1000);
	});
function timeDiff(){
	m = m -1;
	var date = new Date(null);
	date.setSeconds(m);
	var n = date.toISOString().substr(11,8);
	document.getElementById("t").innerHTML = n;
	}
	
	document.getElementById("y").onclick = function (){
		if (this.innerHTML =="Paid"){
			//open.dialog(w+"/source/ajax/dialog/profilePicture.php");
			alert(w+"/source/login.php");}
		}
		
	document.getElementById("n").onclick = function (){
		if ((this.innerHTML =='Decline' && q !=2) || 
			(this.innerHTML =='Purge' && m < 0) || 
			(this.innerHTML =='Purge' && q ==2)){
			return;
		}else if (this.innerHTML =='Decline' && q ==2){
			alert(r);
			}else{
				alert(p);
				}
	}

</script>
  </body>
</html>