<?php
require_once "../load.php";
\Fr\LS::init();
if ($_SERVER['SCRIPT_NAME'] == "/how-it-works.php" && isset($_GET['q'])) {
  /* We don't want find?q= URLs anymore */
  $_GET['q'] = str_replace(array(
    '%2F',
    '%5C'
  ), array(
    '%252F',
    '%255C'
  ), urlencode($_GET['q']));
  $To        = $_GET['q'] == "" ? "" : "/{$_GET['q']}";
  $OP->redirect("/how-it-works.php$To", 301);
  /* See $OP->redirect() in config.php */
}
?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<title> How_It_Works | zikafund - Keep the money flowing...</title>
  </head>
  <body>
    <?php
    include "$docRoot/inc/header.php";
	?>
    <div class="icontent" style="background:white; margin-top:180px;border:0px; min-height:100%;">
		<center><div class="heading text-center" style="color:green;">	
        <h1>HOW IT WORKS</h1>
						<p>
     						<ol>
      							<li>Create a Zikafund account (This will automatically match you with someone to pay to</li>
                                <li>Log into your dashboard and get the details of the person to pay to</li>
                                <li>Make payments and upload proof of payment</li>
                                <li>Get match to recieve payment (100% return in hours)</li>
                                <li>Cash your money and smile.</li>
     						</ol>
    					</p>
    					<i>It's that simple</i>
		</div>
     </div>
<?php
include "$docRoot/inc/sidemenu.php"; 
include "$docRoot/inc/footer.php";
include "$docRoot/inc/scripts.php"; 
?>
  </body>
</html>
