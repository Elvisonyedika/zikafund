<?php
 require_once "../load.php";
 /* The tab to show/highlight */
if( isset($_GET['part']) ) {
  $_GET['part'] = $_GET['part'] == "tickects" ? "" : $_GET['part'];
}else{
  $_GET['part'] = "";
}
$q         = $_GET['part'];
if(!isset($_GET['id']) && !loggedIn){
  \Fr\LS::init();
}
 ?>
<?php include "$docRoot/inc/styles.php";?>
<!doctype html>
<html>
<head>
<title>Admin | zikafund - Keep the money flowing...</title>	
</head>

<body>
 <?php include "$docRoot/inc/header.php";?>
 <div class="icontent">
 	<div class="main blocks">
        <div class="clearfix left block" style="width:100%";>
          <div class="navigation">
          <form>
          <table>
          	<tr>
          		<th style="width:25%">
            <part <?php if($q=="" || $q=="tickects"){echo"act";}?>>Tickects</part>
            	</th>
                <th style="width:25%">
            <part <?php if($q=="transactions"){echo"act";}?>>Transactions</part>
            	</th>
                <th style="width:25%">
            <part <?php if($q=="flags"){echo"act";}?>>Flags</part>
            	</th>
                <th style="width:25%">
            <part <?php if($q=="users"){echo"act";}?>>Users</part>
            	</th>
            </tr>
          </table>
          </form>
          </div>
          
          <div class="noggler" hide id="tickects" <?php if($q==""){echo"show";}?>>
              <div class="smallbox">
          <?php
		  	$q="tickects";
            		include "$docRoot/inc/feed.php";
  			?>
            </div>
            </div>
            
            
            <div class="noggler" hide id="transactions" <?php if($q=="transactions"){echo"show";}?>>
              <div class="smallbox">
          <?php
		  	$q="transactions";
			$_GET['p'] = !isset($_GET['p']) || $_GET['p'] == "" ? 1 : $_GET['p'];
       	 	$p         = $_GET['p'];
			$sql = $OP->dbh->prepare("SELECT * FROM `transactions` ORDER BY id");
			$count = $sql->rowCount();
          	$sql->execute(array());
			echo "<form>
			<table>
			<tr>
			<th style='width:5%'>S/N</th>
			<th style='width:15%'>Transaction No</th>
			<th style='width:10%'>Amount</th>
			<th style='width:30%'>Description</th>
			<th style='width:20%'>Start Date</th>
			<th style='width:20%'>Status</th>
			</tr>";
					$j = 0;
					while ($r = $sql->fetch()) {
						$j = $j + 1;
						$tID = $r['id'];
					  $rID = $r['rID'];
					  $sID = $r['sID'];
					  $amount = $r['amount'];
					  $created = $r['created'];
					  $sName   = get("name", $sID, false);
					  $rName   = get("name", $rID, false);
					  $Desc = $sName." sent to ". $rName;
					  $statusID = $r['statusID'];
					  if(!class_exists("Ec")){
             			 require_once "$docRoot/inc/class.ecoin.php";
						}       	
						/*Get the status name*/
						$HRep = new Ec();
						$status = $HRep->getStatus($statusID);

				echo "<tr>
					 <td><input class='details' type='text' value=$j disabled='disabled'></td>
					 <td><input class='details' type='text' value=$tID disabled='disabled'></td>
					 <td><input class='details' type='text' value=$amount disabled='disabled'></td>
					 <td><input class='details' type='text' value='$Desc' disabled='disabled'></td>
					 <td><input class='details' type='text' value=$created disabled='disabled'></td>
					 <td><input class='details' type='text' value=$status disabled='disabled'></td>
					 </tr>"; 
			}
				echo "</table></form>"; 
                $totalpage = (ceil($sql->rowCount() / 20));
				$lastpage = $totalpage;
				$pagination = "";
				$currentpage    = (isset($_GET['p']) ? $_GET['p'] : 1);
				$loopcounter = ( ( ( $currentpage + 9 ) <= $lastpage ) ? ( $currentpage + 9 ) : $lastpage );
				$startCounter =  ( ( ( $currentpage - 2 ) >= 3 ) ? ( $currentpage - 2 ) : 1 );
				
				echo "<center style='overflow-x:auto;margin-top:10px;padding-bottom:10px;'>";
				echo "<div id='s7e9v'>";
				  echo '<a href="?p=1" class="button b-red" style="width:200px;">First</a>';
				  for($i = $startCounter; $i <= $loopcounter; $i++){
					$isC = $i == $p ? "class='b-green'" : "";
					echo "<a href='?p=$i&q=$q'><button $isC>$i</button></a>";
				  }
				  echo '<a href="?p='.$totalpage.'" class="button b-red" style="width:200px;">Last</a>';
				echo "</div>";
				echo "</center>";
				echo "<cl/>$count Result(s) Found.";
				?>
       		 <style>div[field]{margin:5px;}</style>
            </div>
            </div>
            
            
            <div class="noggler" hide id="flags" <?php if($q=="flags"){echo"show";}?>>
              <div class="smallbox">
          <?php
		  	$q="flags";
			$_GET['p'] = !isset($_GET['p']) || $_GET['p'] == "" ? 1 : $_GET['p'];
       	 	$p         = $_GET['p'];
			$sql = $OP->dbh->prepare("SELECT * FROM `transactions` WHERE `statusID` = 8 AND `sProve` !='' ORDER BY id");
			$count = $sql->rowCount();
          	$sql->execute(array());
			echo "<form>
			<table>
			<tr>
			<th style='width:5%'>S/N</th>
			<th style='width:15%'>Transaction No</th>
			<th style='width:10%'>Amount</th>
			<th style='width:25%'>Sender</th>
			<th style='width:25%'>Reciever</th>
			<th style='width:20%'>Proof</th>
			</tr>";
					$j = 0;
					while ($r = $sql->fetch()) {
						$j = $j + 1;
						$tID = $r['id'];
					  $rID = $r['rID'];
					  $sID = $r['sID'];
					  $amount = $r['amount'];
					  $created = $r['created'];
					  $picAdd = $r['sProve'];
					  $sName   = get("name", $sID, false);
					  $sPhone   = get("phone", $sID, false);
					  if(!class_exists("Ec")){
             			 		require_once "$docRoot/inc/class.ecoin.php";
						}       	
						/*Get the status name*/
						$HRep = new Ec();
						$rDetails = $HRep->getDetails($rID);
						$rname = $rDetails['uName'];
						$rphone = $rDetails['uPhone'];
						$rbank = $rDetails['bName'];
						$rAccNo = $rDetails['accNo'];
						$rAccName = $rDetails['accName'];
				echo "<tr>
					 <td><input class='details' type='text' value=$j disabled='disabled'></td>
					 <td><input class='details' type='text' value=$tID disabled='disabled'></td>
					 <td><input class='details' type='text' value=$amount disabled='disabled'></td>
					 <td><input class='details' type='text' value=$sName,$sPhone disabled='disabled'>
					 <a id='y' href='../inc/order.php?val=Confirm?$tID?8' style='color:green;'>Confirm</a></td>
					<td><input class='details' type='text' value=$rname,$rphone,$rbank,$rAccNo,$rAccName disabled='disabled'>
					 <a id='n' href='../inc/order.php?val=Decline?$tID?8' style='color:red;'>Decline</a></td>
					 <td><input class='details' type='text' value='$picAdd' disabled='disabled'>
					 <a id='n' href='$picAdd' target='_blank' style='color:blue;'>View</a></td>
					 </tr>"; 
			}
				echo "</table></form>"; 
                $totalpage = (ceil($sql->rowCount() / 20));
				$lastpage = $totalpage;
				$pagination = "";
				$currentpage    = (isset($_GET['p']) ? $_GET['p'] : 1);
				$loopcounter = ( ( ( $currentpage + 9 ) <= $lastpage ) ? ( $currentpage + 9 ) : $lastpage );
				$startCounter =  ( ( ( $currentpage - 2 ) >= 3 ) ? ( $currentpage - 2 ) : 1 );
				
				echo "<center style='overflow-x:auto;margin-top:10px;padding-bottom:10px;'>";
				echo "<div id='s7e9v'>";
				  echo '<a href="?p=1" class="button b-red" style="width:200px;">First</a>';
				  for($i = $startCounter; $i <= $loopcounter; $i++){
					$isC = $i == $p ? "class='b-green'" : "";
					echo "<a href='?p=$i&q=$q'><button $isC>$i</button></a>";
				  }
				  echo '<a href="?p='.$totalpage.'" class="button b-red" style="width:200px;">Last</a>';
				echo "</div>";
				echo "</center>";
				echo "<cl/>$count Result(s) Found.";
				?>
       		 <style>div[field]{margin:5px;}</style>
            </div>
            </div>

          
          <div class="noggler" hide id="users" <?php if($q=="Users"){echo"show";}?>>
              <div class="smallbox">
                	<?php 			$_GET['p'] = !isset($_GET['p']) || $_GET['p'] == "" ? 1 : $_GET['p'];
       	 	$p         = $_GET['p'];
			$sql = $OP->dbh->prepare("SELECT * FROM `users` ORDER BY id");
          	$sql->execute(array());
			$count = $sql->rowCount();
			echo "<form>
			<table>
			<tr>
			<th style='width:5%'>S/N</th>
			<th style='width:15%'>User No</th>
			<th style='width:10%'>Name</th>
			<th style='width:40%'>Email</th>
			<th style='width:30%'>Phone</th>
			</tr>";
					$j = 0;
					while ($r = $sql->fetch()) {
						$j = $j + 1;
						$tID = $r['id'];
					  $name = $r['name'];
					  $email = $r['username'];
					  $phone = $r['phone'];
				echo "<tr>
					 <td><input class='details' type='text' value=$j disabled='disabled'></td>
					 <td><input class='details' type='text' value=$tID disabled='disabled'></td>
					 <td><input class='details' type='text' value=$name disabled='disabled'></td>
					 <td><input class='details' type='text' value='$email' disabled='disabled'></td>
					 <td><input class='details' type='text' value=$phone disabled='disabled'></td>
					 </tr>"; 
			}
				echo "</table></form>"; 
                $totalpage = (ceil($sql->rowCount() / 20));
				$lastpage = $totalpage;
				$pagination = "";
				$currentpage    = (isset($_GET['p']) ? $_GET['p'] : 1);
				$loopcounter = ( ( ( $currentpage + 9 ) <= $lastpage ) ? ( $currentpage + 9 ) : $lastpage );
				$startCounter =  ( ( ( $currentpage - 2 ) >= 3 ) ? ( $currentpage - 2 ) : 1 );
				
				echo "<center style='overflow-x:auto;margin-top:10px;padding-bottom:10px;'>";
				echo "<div id='s7e9v'>";
				  echo '<a href="?p=1" class="button b-red" style="width:200px;">First</a>';
				  for($i = $startCounter; $i <= $loopcounter; $i++){
					$isC = $i == $p ? "class='b-green'" : "";
					echo "<a href='?p=$i&q=$q'><button $isC>$i</button></a>";
				  }
				  echo '<a href="?p='.$totalpage.'" class="button b-red" style="width:200px;">Last</a>';
				echo "</div>";
				echo "</center>";
				echo "<cl/>$count Result(s) Found.";
				?>
       		 <style>div[field]{margin:5px;}</style>

              </div>
           </div>
        </div>
     </div>
 </div>
 
 </div>
 
 
 <?php 
	include "$docRoot/inc/sidemenu.php";
    include "$docRoot/inc/scripts.php";
	?>
<style>
.icontent {
    margin-top: 7%;
}
@media screen and (max-width: 1050px){
.icontent {
	width: 100%;
    margin-top: 12%;
}
.main .left.clearfix .navigation part {
    font-size: 45px; 
    margin-left: 0px;
    padding: 0px 0px 0px 0px;
    display: inline-block; 
    cursor: pointer;
    /* margin-top: 30px; */
}
.main .left.clearfix .navigation part[act] {
    font-weight: bold;
    height: 60px;
    border-bottom: 3px solid #F30;
}
}
</style>

</body>
</html>