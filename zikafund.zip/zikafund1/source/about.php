<?php
require_once "../load.php";
\Fr\LS::init();
if ($_SERVER['SCRIPT_NAME'] == "/about.php" && isset($_GET['q'])) {
  /* We don't want find?q= URLs anymore */
  $_GET['q'] = str_replace(array(
    '%2F',
    '%5C'
  ), array(
    '%252F',
    '%255C'
  ), urlencode($_GET['q']));
  $To        = $_GET['q'] == "" ? "" : "/{$_GET['q']}";
  $OP->redirect("/about.php$To", 301);
  /* See $OP->redirect() in config.php */
}
?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<title> About_Us | zikafund - Keep the money flowing...</title>
  </head>
  <body>
    <?php
    include "$docRoot/inc/header.php";
	?>
    <div class="icontent" style="background:white; margin-top:180px;border:0px; min-height:100%;">
		<center><div class="heading text-center" style="color:green;">	
        <h1>ABOUT US</h1>
<p>zikafund was founded with the sole aim of providing a user friendly online financial communityfor the purpose of empowering individuals and achievement of their financial goals and targets in business and general financial flexibility. Zika fund is an automated system that gives its members 100% return on investment to eneble members achieve their goals, dreams, and aspirations.</p>

		<h1>OUR CORE VALUE</h1>
<p>We are more that just a platform, we are a community and our core value is helping one another grow through mutual aid and donations. We strive to eradicte lowly life and bolster overall standard of living by enabling self dependence and fostering a stronger and better community</p>
		</div>
     </div>
<?php
include "$docRoot/inc/sidemenu.php"; 
include "$docRoot/inc/footer.php";
include "$docRoot/inc/scripts.php"; 
?>
  </body>
</html>
