<?php
require_once "../../load.php";
\Fr\LS::init();
?>
<!DOCTYPE html>
<html>
  <head>
  <title>Change Password - Manage Account | PLW - Let's Connect, Learn and Win</title>          
    <?php include "$docRoot/inc/styles.php";?>		  		  
  </head>
  <body>
    <?php include "$docRoot/inc/header.php";?>
      <div class="content">
        <h2>Change Password</h2>
        <div style="margin:0px auto;width: 60%;">
          <?php
          $status = \Fr\LS::changePassword();
          if( $status == "changePasswordForm" ){
            echo "<p>If you have created account with Facebook or Google, leave the current password blank</p>";
          }
          ?>
        </div>
      </div>
<?php 
	include "$docRoot/inc/sidemenu.php";
	include "$docRoot/inc/gadget.php";
	?>
  </body>
</html>