<?php
require_once "../../load.php";
\Fr\LS::init();
?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  <title>Reset Password - Manage Account | PLW - Let's Connect, Learn and Win</title>
  </head>
  <body>
    <?php include "$docRoot/inc/header.php";?>
      <div class="content blocks">
        <center><h1>Reset Password</h1></center>
        <?php
        $rePass = \Fr\LS::forgotPassword();
        if( $rePass == "resetPasswordForm" ){
          echo "<center><p>Enter your <strong>email</strong> in the field above</p></center>";
        }
        ?>
      </div>
    </div>
    <?php 
	include "$docRoot/inc/sidemenu.php";
	include "$docRoot/inc/gadget.php";
	include "$docRoot/inc/scripts.php"; 
	?>
  </body>
</html>