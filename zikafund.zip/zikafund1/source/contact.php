<?php 
require_once "../load.php";
include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<title> Contact Us | Keep the money flowing...</title>
  </head>
  <body>
    <?php include "$docRoot/inc/header.php";?>
	\Fr\LS::init();  
    <div class="icontent" style="width:100%; min-height:85%; margin-top:-1%;">    
        <div class="content" style="text-align:center; 
        background:white; margin-bottom:10%;border: 2px solid green;">
     <?php
	    if(isset($_POST["subject"]) && isset($_POST["message"]) ) {
	if(loggedIn){
    $name = get("name",$who,false);
    $email = get("username",$who,false);
	$subject = trim($_POST["subject"]);
		}else{
	$who = "";
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
	$subject = trim($_POST["subject"]);
		}
    $message = trim($_POST["message"]);


    if ($name == "" OR $email == "" OR $message == "") {
		$OP->ser("<h1 style='color:red; font-size: 45;'>Fields Left Blank</h1>", 
		"<h1 style='color:red; font-size:30;'>Some Fields were left blank. Please fill up all fields.</h1>");
    }

    foreach( $_POST as $value ){
        if( stripos($value,'Content-Type:') !== FALSE ){
			$OP->ser("<h1 style='color:red; font-size: 45;'>Problem With Information</h1>", 
			"<h1 style='color:red; font-size:30;'>There was a problem with the information you entered.</h1>");
        }
    }
	
	$sql = $OP->dbh->prepare("INSERT INTO `support_tickets` (
	   `uID`,`name`, `email`, `subject`, `message`, `statusID`, `created`)
	    VALUES (?, ?, ?, ?, ?, 0, now())");
	$sql->execute(array($who, $name, $email, $subject, $message));

        $_GET["status"] = "thanks";
}?>
          <center style="font-size: 45px; font-weight:bold; margin-bottom: 20px; margin-top:20px;">Contact Us</center>

            <?php if (isset($_GET["status"]) AND $_GET["status"] == "thanks") { 
            $OP->sss("<h2>Thanks For Contacting Us</h2>", "<h3>We&rsquo;ll be in touch with you shortly</h3>");
             } else { ?>
		<?php if(loggedIn){include "$docRoot/inc/feed.php";}?>
                <center><p>We&rsquo;d love to hear from you! Complete the form to send us a message.</p><center>

                <form method="post" action="contact.php">

                    <table>
                    <?php if(loggedIn){?>
                    <tr>
                        <select name="subject" id="subject">
                            <option  value="">Choose a topic</option>
                            <?php
                            $select="zikafund";
                            $list = $OP->dbh->prepare("select * from support_topics");
                            $list->execute();
                               while($r = $list->fetch()){
                            ?>
                            <option value=" <?php echo $r['name'];?>"<?php
                                if($r['id']==$select){echo "selected";}?>>
                                    <?php echo $r['name']?>
                                    </option>
                                    <?Php
                                }
                                    ?>
                        </select>
           `		</tr>
                    <?php }else{?>
                        <tr>
                            <input type="text" name="name" id="name" placeholder="Name">
                        </tr>
                        <tr>
                            <input type="text" name="email" id="email" placeholder="Email">
                        </tr>
                        <tr>
                            <input type="text" name="subject" id="subject" placeholder="Subject">
                        </tr>
                    <?php }?>
                        <tr>
                            <textarea style="height:500px;" name="message" id="message" placeholder="Message"></textarea>
                        </tr>                   
                    </table>
                    <input type="submit" value="Send">

                </form>

            <?php } ?>
		</div>
    </div>

<?php  
include "$docRoot/inc/sidemenu.php";
include "$docRoot/inc/footer.php"; 
include "$docRoot/inc/scripts.php";
?>
</body>
</html>