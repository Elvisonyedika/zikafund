<?php
require_once "../load.php";
\Fr\LS::init();
if ($_SERVER['SCRIPT_NAME'] == "/transactions.php" && isset($_GET['q'])) {
  /* We don't want find?q= URLs anymore */
  $_GET['q'] = str_replace(array(
    '%2F',
    '%5C'
  ), array(
    '%252F',
    '%255C'
  ), urlencode($_GET['q']));
  $To        = $_GET['q'] == "" ? "" : "/{$_GET['q']}";
  $OP->redirect("/transactions.php$To", 301);
  /* See $OP->redirect() in config.php */
}
?>
<?php 
    include "$docRoot/inc/header.php";
    include "$docRoot/inc/styles.php";
    include "$docRoot/inc/sidemenu.php";
    include "$docRoot/inc/scripts.php";
?>
<!DOCTYPE html>
<html>
  <head>
  	<title> Transactions | zikafund - Keep the money flowing...</title>
  </head>
  <body>
    <?php
    $_GET['q'] = isset($_GET['q']) ? $_GET['q'] : "";
    $_GET['q'] = str_replace(array(
      '%5C',
      '/'
    ), array(
      '%255C',
      '%252F'
    ), $_GET['q']);
    $q         = $OP->format($_GET['q']);
		
		if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            }       	
			$HRep = new Ec();
            $HRep = $HRep->uBal($who);
    ?>
      <div class="icontent" style=" margin-top:120px;">
        <h1>Transactions</h1>
        <form action="/zikafund/source/transactions.php" style='margin: 20px;'>
          <span>Search </span><input type="text" name="q" value="<?php echo $q;?>" size="35"/></br>
          <span>Available Bal: </span><input class='details' type='text' value="N <?php echo $HRep['avBal'];?>" 
          	disabled='disabled' size="3">
          <span>Book Bal: </span><input class='details' type='text' value="N <?php echo $HRep['bkBal'];?>" 
          	disabled='disabled' size="3">
          <span>Paid Out: </span><input class='details' type='text' value="N <?php echo $HRep['paidOut'];?>" 
          	disabled='disabled' size="3">
        </form><cl/>
        <?php
        $_GET['p'] = !isset($_GET['p']) || $_GET['p'] == "" ? 1 : $_GET['p'];
        $p         = $_GET['p'];
        if ($q != '' && $p == '1') {
          $sql = $OP->dbh->prepare("SELECT id FROM `transactions` WHERE name LIKE :q AND id!=:who ORDER BY id LIMIT 30");
          $sql->execute(array(
            ":who" => $who,
            ":q" => "%$q%"
          ));
        } elseif ($p != "1") {
          $start = ($p - 1) * 10;
          $limit = 30;
          if ($q == "") {
            $sql = $OP->dbh->prepare("SELECT id FROM `transactions` WHERE id!=:who ORDER BY id LIMIT :start,:limit");
            $sql->bindValue(':limit', $limit, PDO::PARAM_INT);
            $sql->bindValue(':start', $start, PDO::PARAM_INT);
            $sql->bindValue(':who', $who);
            $sql->execute();
          } else {
            $sql = $OP->dbh->prepare("SELECT id FROM `transactions` WHERE name LIKE :q AND id!=:who ORDER BY id LIMIT :start,:limit");
            $sql->bindValue(':limit', $limit, PDO::PARAM_INT);
            $sql->bindValue(':start', $start, PDO::PARAM_INT);
            $sql->bindValue(':who', $who);
            $sql->bindValue(':q', "%$q%");
            $sql->execute();
          }
        } else {  
          $sql = $OP->dbh->prepare("SELECT * FROM `transactions` WHERE `rID`=:who OR `sID`=:who ORDER BY id LIMIT 10");
          $sql->execute(array(
            ":who" => $who
          ));
        }
        if ($sql->rowCount() == 0) {
          if ($q == '') {
            $OP->ser("No Transation Found !", "You have not done any transaction yet.");
            exit;
          } else {
            $OP->ser("No Transation Found !", "No transaction found for your search.");
            exit;
          }
        }
		$count = $sql->rowCount();
echo "<form>
<table>
<tr>
<th style='width:5%'>S/N</th>
<th style='width:15%'>Transaction No</th>
<th style='width:10%'>Amount</th>
<th style='width:30%'>Description</th>
<th style='width:20%'>Start Date</th>
<th style='width:20%'>End Date</th>
</tr>";
		$j = 0;
        while ($r = $sql->fetch()) {
			$j = $j + 1;
			$tID = $r['id'];
		  $rID = $r['rID'];
		  $sID = $r['sID'];
		  $amount = $r['amount'];
		  $created = $r['created'];
		  $closed = $r['closed'];
          $sName   = get("name", $sID, false);
		  $rName   = get("name", $rID, false);
 if ($rID == $who){
	 $Desc = "You recieved from ". $sName;
	 }else {
		 $Desc = "You sent to ". $rName;
		 }
    echo "<tr>
    	 <td><input class='details' type='text' value=$j disabled='disabled'></td>
		 <td><input class='details' type='text' value=$tID disabled='disabled'></td>
		 <td><input class='details' type='text' value=$amount disabled='disabled'></td>
		 <td><input class='details' type='text' value='$Desc' disabled='disabled'></td>
		 <td><input class='details' type='text' value=$created disabled='disabled'></td>
		 <td><input class='details' type='text' value=$closed disabled='disabled'></td>
    	 </tr>"; 
}
	echo "</table></form>"; ?>
        <?php
        
        if ($q == '') {
          $sql = $OP->dbh->prepare("SELECT * FROM `transactions` WHERE `rID`=:who OR `sID`=:who ORDER BY id");
          $sql->execute(array(
            ":who" => $who
          ));
        } else {
          $sql = $OP->dbh->prepare("SELECT id FROM `transactions` WHERE name LIKE :q AND id!=:who ORDER BY id");
          $sql->execute(array(
            ":who" => $who,
            ":q" => "%$q%"
          ));
        }
        $totalpage = (ceil($sql->rowCount() / 20));
        $lastpage = $totalpage;
        $pagination = "";
        $currentpage    = (isset($_GET['p']) ? $_GET['p'] : 1);
        $loopcounter = ( ( ( $currentpage + 9 ) <= $lastpage ) ? ( $currentpage + 9 ) : $lastpage );
        $startCounter =  ( ( ( $currentpage - 2 ) >= 3 ) ? ( $currentpage - 2 ) : 1 );
        
        echo "<center style='overflow-x:auto;margin-top:10px;padding-bottom:10px;'>";
        echo "<div id='s7e9v'>";
          echo '<a href="?p=1" class="button b-red" style="width:200px;">First</a>';
          for($i = $startCounter; $i <= $loopcounter; $i++){
            $isC = $i == $p ? "class='b-green'" : "";
            echo "<a href='?p=$i&q=$q'><button $isC>$i</button></a>";
          }
          echo '<a href="?p='.$totalpage.'" class="button b-red" style="width:200px;">Last</a>';
        echo "</div>";
        echo "</center>";
        echo "<cl/>$count Result(s) Found.";
        ?>
        <style>div[field]{margin:5px;}</style>
      </div>
    </div>
  </body>
</html>
