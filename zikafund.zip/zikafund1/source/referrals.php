<?php
require_once "../load.php";
\Fr\LS::init();
if ($_SERVER['SCRIPT_NAME'] == "/referrals.php" && isset($_GET['q'])) {
  /* We don't want find?q= URLs anymore */
  $_GET['q'] = str_replace(array(
    '%2F',
    '%5C'
  ), array(
    '%252F',
    '%255C'
  ), urlencode($_GET['q']));
  $To        = $_GET['q'] == "" ? "" : "/{$_GET['q']}";
  $OP->redirect("/referrals.php$To", 301);
  /* See $OP->redirect() in config.php */
}
?>
<?php
    include "$docRoot/inc/header.php";
    include "$docRoot/inc/styles.php";
     include "$docRoot/inc/sidemenu.php";
     include "$docRoot/inc/scripts.php";
?>
<!DOCTYPE html>
<html>
  <head>
  	<title> Referrals | zikafund - Keep the money flowing...</title>
  </head>
  <body>
    <?php
    $_GET['q'] = isset($_GET['q']) ? $_GET['q'] : "";
    $_GET['q'] = str_replace(array(
      '%5C',
      '/'
    ), array(
      '%255C',
      '%252F'
    ), $_GET['q']);
    $q = $OP->format($_GET['q']);
	
		if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            }       	
			$HRep = new Ec();
            $HRep = $HRep->refBonus($who);
			$refLink = HOST."/source/register.php?ref=".$who;
    ?>
      <div class="icontent" style=" margin-top:120px;">
        <h1>Referrals</h1>
        <form action="/zikafund/source/referrals.php" style='margin: 20px;'>
          <span>Search </span><input type="text" name="q" value="<?php echo $q;?>" size="35"/>
          <span>Referral Link: </span><input class='details' type="text" name="q" 
          	value="<?php echo $refLink;?>" disabled='disabled' size="45"/></br>
          <span>Available Bal: </span><input class='details' type='text' value="N <?php echo $HRep['avBal'];?>" 
          	disabled='disabled' size="3">
          <span>Book Bal: </span><input class='details' type='text' value="N <?php echo $HRep['bkBal'];?>" 
          	disabled='disabled' size="3">
          <span>Paid Bonus: </span><input class='details' type='text' value="N <?php echo $HRep['paidBonus'];?>" 
          	disabled='disabled' size="3">
        </form><cl/>
        <?php
        $_GET['p'] = !isset($_GET['p']) || $_GET['p'] == "" ? 1 : $_GET['p'];
        $p         = $_GET['p'];
        if ($q != '' && $p == '1') {
          $sql = $OP->dbh->prepare("SELECT id FROM `users` WHERE name LIKE :q AND ref=:who ORDER BY id LIMIT 30");
          $sql->execute(array(
            ":who" => $who,
            ":q" => "%$q%"
          ));
        } elseif ($p != "1") {
          $start = ($p - 1) * 10;
          $limit = 30;
          if ($q == "") {
            $sql = $OP->dbh->prepare("SELECT id FROM `users` WHERE ref=:who ORDER BY id LIMIT :start,:limit");
            $sql->bindValue(':limit', $limit, PDO::PARAM_INT);
            $sql->bindValue(':start', $start, PDO::PARAM_INT);
            $sql->bindValue(':who', $who);
            $sql->execute();
          } else {
            $sql = $OP->dbh->prepare("SELECT id FROM `users` WHERE name LIKE :q AND ref=:who ORDER BY id LIMIT :start,:limit");
            $sql->bindValue(':limit', $limit, PDO::PARAM_INT);
            $sql->bindValue(':start', $start, PDO::PARAM_INT);
            $sql->bindValue(':who', $who);
            $sql->bindValue(':q', "%$q%");
            $sql->execute();
          }
        } else {  
          $sql = $OP->dbh->prepare("SELECT * FROM `users` WHERE `ref`=:who ORDER BY id LIMIT 10");
          $sql->execute(array(
            ":who" => $who
          ));
        }
        if ($sql->rowCount() == 0) {
          if ($q == '') {
            $OP->ser("No Referral Found !", "You have not referred anybody to this system.
			Use your referral link above to referr people to this system and earn N 1000 per referral.");
            exit;
          } else {
            $OP->ser("No Referral Found !", "No Referral found for your search.");
            exit;
          }
        }
		$count = $sql->rowCount();
echo "<form>
<table>
<tr>
<th style='width:5%'>S/N</th>
<th style='width:20%'>Name</th>
<th style='width:30%'>Email</th>
<th style='width:10%'>Phone</th>
<th style='width:15%'>Joined</th>
<th style='width:15%'>Status</th>
</tr>";
		$j = 0;
        while ($r = $sql->fetch()) {
			$j = $j + 1;
			$ID = $r['id'];
          $name   = get("name", $ID, false);
		  $email   = get("username", $ID, false);
          $phone   = get("phone", $ID, false);
		  $Joined   = get("Joined", $ID, false);
    echo "<tr>
    	 <td><input class='details' type='text' value=$j disabled='disabled'></td>
		 <td><input class='details' type='text' value=$name disabled='disabled'></td>
		 <td><input class='details' type='text' value=$email disabled='disabled'></td>
		 <td><input class='details' type='text' value=$phone disabled='disabled'></td>
		 <td><input class='details' type='text' value=$Joined disabled='disabled'></td>
		 <td><input class='details' type='text' value='Activated' disabled='disabled'></td>
    	 </tr>"; 
}
	echo "</table></form>"; ?>
        <?php
        
        if ($q == '') {
          $sql = $OP->dbh->prepare("SELECT * FROM `users` WHERE `ref`=:who ORDER BY id");
          $sql->execute(array(
            ":who" => $who
          ));
        } else {
          $sql = $OP->dbh->prepare("SELECT id FROM `users` WHERE name LIKE :q AND `ref`=:who ORDER BY id");
          $sql->execute(array(
            ":who" => $who,
            ":q" => "%$q%"
          ));
        }
        $totalpage = (ceil($sql->rowCount() / 20));
        $lastpage = $totalpage;
        $pagination = "";
        $currentpage    = (isset($_GET['p']) ? $_GET['p'] : 1);
        $loopcounter = ( ( ( $currentpage + 9 ) <= $lastpage ) ? ( $currentpage + 9 ) : $lastpage );
        $startCounter =  ( ( ( $currentpage - 2 ) >= 3 ) ? ( $currentpage - 2 ) : 1 );
        
        echo "<center style='overflow-x:auto;margin-top:10px;padding-bottom:10px;'>";
        echo "<div id='s7e9v'>";
          echo '<a href="?p=1" class="button b-red" style="width:200px;">First</a>';
          for($i = $startCounter; $i <= $loopcounter; $i++){
            $isC = $i == $p ? "class='b-green'" : "";
            echo "<a href='?p=$i&q=$q'><button $isC>$i</button></a>";
          }
          echo '<a href="?p='.$totalpage.'" class="button b-red" style="width:200px;">Last</a>';
        echo "</div>";
        echo "</center>";
        echo "<cl/>$count Result(s) Found.";
        ?>
        <style>div[field]{margin:5px;}</style>
      </div>
    </div>
  </body>
</html>
