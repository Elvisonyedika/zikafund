<?php
require_once "../load.php";
\Fr\LS::init();
if ($_SERVER['SCRIPT_NAME'] == "/about.php" && isset($_GET['q'])) {
  /* We don't want find?q= URLs anymore */
  $_GET['q'] = str_replace(array(
    '%2F',
    '%5C'
  ), array(
    '%252F',
    '%255C'
  ), urlencode($_GET['q']));
  $To        = $_GET['q'] == "" ? "" : "/{$_GET['q']}";
  $OP->redirect("/testimonials.php$To", 301);
  /* See $OP->redirect() in config.php */
}
?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<title> Testimonials | zikafund - Keep the money flowing...</title>
  </head>
  <body>
    <?php
    include "$docRoot/inc/header.php";
    	?>
	 <div class="icontent" style=" margin-top:70px;">
        <h1>Under Construction. Will be ready soon</h1>
    <?php    
    include "$docRoot/inc/sidemenu.php";
    ?>
     </div>
  </body>
</html>