<?php
require_once "../load.php";
if(isset($_GET['logout']) && $_GET['logout'] == "true"){
  \Fr\LS::logout();
}
\Fr\LS::init();

$_GET['c'] = isset($_GET['c']) ? $_GET['c'] : "";
$returnURL = urldecode($_GET['c']);
$returnURL = $returnURL == "" ? "/zikafund/source/home.php" : $returnURL;

if(isset($_POST['submit'])){
  $user = $OP->format($_POST['user']);
  $pass = $OP->format($_POST['pass']);
  if( $pass != "" && \Fr\LS::login($user, $pass, isset($_POST['remember_me'])) ){
   header("Location: $returnURL");
    exit;
  }else{
    $error = 'E-Mail/Password is Incorrect';
  }
}
if(isset($_GET['logout']) && $_GET['logout'] == "true"){
  \Fr\LS::logout();
}elseif(loggedIn){
  header("Location: $returnURL");
  exit;
}
include "$docRoot/inc/styles.php";
?>
<!DOCTYPE html>
<html>
  <head>
  	<title>Login | Keep the money flowing...</title>
  </head>
  <body>
    <?php include "$docRoot/inc/header.php"; ?> 
    <div class="icontent" style="width:100%; min-height:85%;">
        <div class="content" style="text-align:center; height:650px; 
        background:white; margin-bottom:10%;border: 2px solid green;">
          <center style="font-size: 45px; font-weight:bold; margin-bottom: 20px; margin-top:20px;">Log In</center>
          <form action="login.php?c=<?php echo urlencode($returnURL);?>" method="POST">
           <table>
          	<tr>
              		<input type="text" name="user" placeholder="E-Mail"></br>
           	
              		<input name="pass" autocomplete="off" type="password" placeholder="Password"></br>
            	
                	<center><p><label for="checkbox">Remember Me</label></p>
                	<input type="checkbox" class="block" name="remember_me"></center> 
              	
            </tr>                   
          </table>
                    <input type="submit" name="submit" value="Log In">
          </form>
          <center>
           	<p>Don't have an account ?: <a  href="<?php echo HOST;?>/source/register.php" class="button b-blue" style="margin:30px">Register</a></br></cl>
           	Forgot Your Password ?: <a  href="<?php echo HOST;?>/source/me/ResetPassword.php" class="button b-blue" style="margin:30px;">Reset Password</a></p>
          </center>          
          </form>
          <?php
          if(isset($error)){
            $OP->ser($error, "", "html", false);
          }?>
          </div>
          <?php
	include "$docRoot/inc/sidemenu.php";
	include "$docRoot/inc/footer.php";
	include "$docRoot/inc/scripts.php";
	?>
    </div>
  </body>
</html>
