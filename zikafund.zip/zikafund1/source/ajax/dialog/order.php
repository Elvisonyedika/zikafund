<?php 
require_once "../../../load.php";
//\Fr\LS::init();
$str = isset($_GET['o']) ? $_GET['o'] : "";
$str = explode('?',$str);
$soID = $str[1];
$tID = $str[0];
$tStatusID = $str[2];
?>
<!DOCTYPE html>
<html>
  <head>
    <?php /* Ubuntu font in ubuntu,linux machines. Elsewhere it's the browser's default font */?>
    <style>*{font-family:ubuntu;}</style>
  </head>
  <body>
  	<?php if ($tStatusID == 2){?>
    <div style="margin-top:150px; text-align:center;">
	<h1>You Have Marked This Transaction As Paid</h1>
	<p>Please Wait Patiently To Be Confirmed</p>
    </div>
	<?php exit;}?>
    <div style="margin-top:150px; text-align:center;">
    <h1>Upload A Proof Of Payment</h1>
    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="file"/>
      <button>Upload File</button>
      <p>PNG, JPG (JPEG) & GIF files are supported</p>
    </form>
    </div>
    <?php
    if(isset($_FILES['file'])){
      include_once "$docRoot/source/data/add.php";
      $imageFile = $_FILES['file'];
      $uploadFileURL = upload($tID, "profile_pic", $imageFile, 200, 200);
      if($uploadFileURL == "extensionNotSupported"){ /* Was the upload finished successfully ? */
        $OP->ser("Extensions Not Supported", "The extension is not supported. Use supported image extensions");
      }elseif($uploadFileURL){
        /**
         * Save the image URL
         */
		 $newName = $tID.".profile_pic.png";
		 $target = "$docRoot/cdn/img/avatars/$newName";
		 move_uploaded_file($_FILES['file']['tmp_name'], $target);
        /*$OP->save("img", $uploadFileURL); 
		 $sql = $OP->dbh->prepare("UPDATE `transactions` SET `sProve` = ?, `statusID` = '2' WHERE `id`=?");
         $sql->execute(array($uploadFileURL,$tID));Not needed anymore*/
		 
		 $sostID = 2;
		 $tstID = 2;
		 $rIndic = 1;
		 $closed = date('Y-m-d H:i:s');
		 if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            } 
		 $HRep = new Ec();
		 $upDate = $HRep->upDate($tID, $rIndic, $sostID, $tstID, $closed,$uploadFileURL);
        /**
         * and show success message
         */
        $OP->sss("File Uploaded", "The file you gave was successfully uploaded and your order has been marked as paid.
		 You will be confirmed soon</b>");
      }else{
        /* Or error message */
        $OP->ser("Error Uploading file", "Something Happened. Try Uploading again.");
      }
    }else{
    ?>
    <?php
    }
    ?>
  </body>
</html>
