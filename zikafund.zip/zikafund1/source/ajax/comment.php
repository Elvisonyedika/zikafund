<?php
require_once "../../load.php";
require_once "$docRoot/inc/render.php";
\Fr\LS::init();

if($_P){
  $id = $_POST['id'];
  $msg = $_POST['cmt'];
  if(!preg_match("/[^\s]/", $msg)){
    $OP->ser("Reply box can't be blank", "", "json");
  }
  if(!is_numeric($id)){
    $OP->ser("Invalid Request", "", "json");
  }
  $sql = $OP->dbh->prepare("SELECT `uid` FROM `support_tickets` WHERE `id`=?");
  $sql->execute(array($id));
  $owner = $sql->fetchColumn();
 
  if($sql->rowCount() != 0){
    $OP->format($msg, true); /* Just For @mention notifications */
    $sql = $OP->dbh->prepare("INSERT INTO `comments` (`uid`, `pid`, `comment`, `time`) VALUES(:uid, :id, :msg, NOW());
      UPDATE `support_tickets` SET `replies` = `replies` + 1 WHERE `id`=:id");
    $sql->execute(array(
      ":uid" => curUser,
      ":id" => $id,
      ":msg" => $msg
    ));
    $OP->mentionNotify($id, "answer");
  
    $OP->notify("comment", $msg, $id, $owner, curUser);/* We should notify the owner of post */
  
    /* Show all comments or not */
    if($_POST['clod'] == 'mom'){
      $_POST['all'] = 1;
    }
    $html = $OP->rendFilt(Render::comment($id));
?>
$("#<?php echo $id;?>.comments").replaceWith("<?php echo $html;?>");
$("#<?php echo $id;?>.comments").show();
$("#<?php echo $id;?>.ck.count").text(parseFloat($("#<?php echo $id;?>.ck.count").text())+1);
<?php
  }else{
    $OP->ser("I can't find the question you wish to.", "", "json");
  }
}else{
  $OP->ser();
}
?>