<?php
require_once "../../load.php";
require_once "$docRoot/inc/render.php";
if(isset($_POST['uid']) && $_POST['uid']==''){
  \Fr\LS::init();
}
$lastPID = isset($_POST['id']) ? $OP->format($_POST['id']) : ""; /* The last Post ID */

if($lastPID != ""){
$nemife = array(1,2,3,4,5,6,7,8,9,10,22,36);
if (in_array($who,$nemife)){
   $sql = $OP->dbh->prepare("SELECT * FROM `support_tickets`
   WHERE id < :lid 
   ORDER BY id DESC LIMIT 10");
   $sql->execute(array(
   	  ":lid" => $lastPID
   ));
}else{
    $sql = $OP->dbh->prepare("SELECT * FROM `support_tickets` 
   WHERE `uID`=:id AND id < :lid 
   ORDER BY id DESC LIMIT 10");
   $sql->execute(array(
      ":id" =>  $who,
	  ":lid" => $lastPID
   ));
}

   $postCount = $sql->rowCount();
   $postsArr = $sql->fetchAll(PDO::FETCH_ASSOC);
   $html = $OP->rendFilt(Render::post($postsArr));
?>
  <?php
  if($postCount == 0){
    echo '$(".load_more_posts").find(".normal").text("No More Posts To Show");';
  }else{
  ?>
    $(".post:last").after("<?php echo $html;?>");
  <?php
  }
  echo '$(".load_more_posts").find(".normal").show();';
}
echo 'localStorage["requested"] = 0;';
echo '$(".load_more_posts .loader").hide();';
echo '$(".load_more_posts").find(".normal").text("No More Posts To Show").show();';
?>