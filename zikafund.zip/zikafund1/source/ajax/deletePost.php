<?php
require_once "../../load.php";
\Fr\LS::init();
$id=$_POST['id'];
if($_P && is_numeric($id)){
 $sql=$OP->dbh->prepare("DELETE FROM support_tickets WHERE id=? AND uID=?");
 $sql->execute(array($id, $who));
 if($sql->rowCount()==0){
  $OP->ser();
 }else{
  $sql=$OP->dbh->prepare("DELETE FROM comments WHERE pid=?");
  $sql->execute(array($id));
?>
$(".post#<?php echo$id?>").remove();
<?php
 }
}else{
 $OP->ser();
}
?>
