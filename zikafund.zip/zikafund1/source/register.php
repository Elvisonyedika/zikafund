<?php 
require_once "../load.php";
\Fr\LS::init();
$ref = isset($_GET['ref']) ? $_GET['ref'] : "";
$pkID = isset($_GET['pkID']) ? $_GET['pkID'] : "";
$list = $OP->dbh->prepare("select * from packages where id = ?");
$list->execute(array($pkID));
$r = $list->fetch();
$pkg = $r>0 ? "Package: ".$r['name']."  N".$r['price'] : "Choose a Package";
?>

<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
  <head>
  	<meta name="type" value="register"></meta>
  	<title>Sign Up | Keep the money flowing...</title>
  </head>
  <body>
    <?php include "$docRoot/inc/header.php";?>
	<div class="icontent" style="width:100%; min-height:85%;">
    <div class="content blocks" style="text-align:center; margin-bottom:10%;border: 2px solid green;">
              
        <?php
        if(isset($_POST['submit'])){
			/*User details*/
          $email = strtolower($OP->format($_POST['a']));
          $pass = $OP->format($_POST['pass']);
          $pass2 = $OP->format($_POST['pass2']);
          $name = $OP->format($_POST['name']);
	  $phone = $OP->format($_POST['phone']);
	  $joined = date("Y-m-d H:i:s");
	  $ref = $ref > 0 ? $ref : $OP->format($_POST['ref']);
		  if ($ref=="") {$ref = 1;}
          /*Bank details*/
		  $accName = $OP->format($_POST['accName']);
          $accNo = $OP->format($_POST['accNo']);
		  $bank = $OP->format($_POST['bank']);
		  /*Package*/
          $pkID = $pkID > 0 ? $pkID : $OP->format($_POST['package']);
          

          if($email == "" || $pass == '' || $pass2 == '' || $name == ''|| $phone == '' || $ref == ''){
            $OP->ser("<h1 style='color:red; font-size: 45;'>Fields Left Blank</h1>", 
			"<h1 style='color:red; font-size:30;'>Some Fields were left blank. Please fill up all fields.</h1>");
          }
          if($pkID < 1){
            $OP->ser("<h1 style='color:red; font-size: 45;'>Package Not Selected</h1>", 
			"<h1 style='color:red; font-size:30;'>You must select a package before you can complete your registration.</h1>");
          }
          if( !ctype_alnum(strtolower(str_replace(" ", "", $name))) ){
            $OP->ser("<h1 style='color:red; font-size: 45;'>Invalid Name</h1>", 
			"<h1 style='color:red; font-size:30;'>The Name is not valid. Only ALPHANUMERIC characters are allowed.</h1>");
          }
          if($pass != $pass2){
            $OP->ser("<h1 style='color:red; font-size: 45;'>Passwords Don't Match</h1>", 
			"<h1 style='color:red; font-size:30;'>The Passwords you entered didn't match</h1>");
          }
          $json = '{"joined":"'.date("Y-m-d H:i:s").'"}';
		  
		  if(!\Fr\LS::validEmail($email)){
            $OP->ser("<h1 style='color:red; font-size: 45;'>E-Mail Is Not Valid</h1>", 
			"<h1 style='color:red; font-size:30;'>The E-Mail you submitted is not a valid E-Mail</h1>");
          }
          if( \Fr\LS::userExists($email) ){
            $OP->ser("<h1 style='color:red; font-size: 45;'>You Already Have An Account!</h1>", 
			"<h1 style='color:red; font-size:30;'>There is already an account registered with the E-Mail you have given.</h1>
			 <a style='font-weight: bold; font-size: 30;  color: blue;' 
			 href='http://localhost/zikafund/source/me/ResetPassword.php'>Forgot Password ?</a>");
          }
          
          $createAccount = \Fr\LS::register($email, $pass, array(
            "name" => $name,
            "joined" => $joined,
			"phone" => $phone,
			"ref" => $ref,
            "seen" => ""
          ));
          if ($createAccount === true){
			  
			   /*Update account detail*/
	  $sql = $OP->dbh->prepare("SELECT `id` FROM `users` WHERE `username`=?");
      $sql->execute(array($email));
	  $r = $sql->fetch();
	  $uid = $r['id'];
	  $sql = $OP->dbh->prepare("INSERT INTO `bank_details` (`uid`, `Acc_name`, `Acc_no`, `Bank`) 
	  		VALUES (?, ?, ?, ?)");
   	  $sql->execute(array($uid, $accName, $accNo, $bank));
			  
			  /*Delete entry from verify table if exist*/
	  $sql = $OP->dbh->prepare("SELECT 1 FROM `verify` WHERE `email`=?");
      $sql->execute(array($email));
	  if ($sql->rowCount() !=0){
	  $sql = $OP->dbh->prepare("DELETE FROM `verify` WHERE `email`=?");
	  $sql->execute(array($email));
	  }
	         	
			/*Create order*/
	  $list = $OP->dbh->prepare("select * from packages where id = ?");
	  $list->execute(array($pkID));
	  $r = $list->fetch();
	  $rInv = $r['price'] * 2;
		if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            }
			$HRep = new Ec();
			$pay = $HRep->createOrder($uid, $pkID, $rInv, $rInv);
			$bonus = $HRep->createRefBonus($ref, $uid,$amount);
	  
          $OP->sss("Registration Successful", "Your account and donation order has been created. Log In 
		  		<a style='font-weight: bold; font-size: 20;  color: blue;' href='login.php'>
				here</a> to access your dashboard");
		  }else echo $createAccount;
        }else {
        ?>
       <center style="font-size: 45px; font-weight:bold; margin-bottom: 20px; margin-top:20px;">Basic Info</center>
          <form action="register.php" method="POST">
            <table>
          	<tr>
              		<input type="text" name="a" placeholder="Type Your Email Address">
            </tr>
            <tr>
              		<input name="pass" autocomplete="off" type="password" id="pass" placeholder="Type Your Password">
            </tr>
            <tr>
              		<input name="pass2" autocomplete="off" type="password" id="pass2" placeholder="Re-type Your Password">
            </tr>
            <!--<div id="ppbar" title="Strength"><div id="pbar"></div><div id="ppbartxt"></div></div>-->
            <tr>
              		<input name="name" id="user" placeholder="You Must Have a Name" type="text">
            </tr>
            <tr>
              		<input name="phone" id="phone" placeholder="Type your phone number" type="number">
            </tr>
            <tr>
              		<input name="ref" id="ref" placeholder="Type the email of your referral" type="text">
                    <center><p>Leave blank if you don't have a referrer</p></center>
            </tr>
            </table>
        <div style="margin-bottom: 20px; border-top:2px solid green; margin-top:40px;"></div>
        <center  style="font-size: 45px; font-weight:bold;">Account Details</center>
            <table>
          	<tr>
              		<input name="accName" id="AccName" placeholder="Type your account name" type="text">            
            </tr>
            <tr>
              		<input name="accNo" id="AccNo" placeholder="Type your account number" type="number">
            </tr>
            <tr>
              		<input name="bank" id="Bank" placeholder="Type your bank name" type="text">
            </tr>
            </table>
        <div style="margin-bottom: 20px; border-top:2px solid green; margin-top:40px;"></div>
        <center  style="font-size: 45px; font-weight:bold;"><?php echo $pkg;?></center>
            <table>
            <tr <?php if ($pkID > 0) echo 'style="display:none;"'?>>
                	<select name="package" id="package">
                        <option  value="">Select a Package</option>
                        <?php
                        $select="zikafund";
                        $list = $OP->dbh->prepare("select * from packages ");
                        $list->execute();
                           while($r = $list->fetch()){
                        ?>
                        <option value=" <?php echo $r['id'];?>"<?php
                            if($r['id']==$select){echo "selected";}?>>
                                <?php echo $r['name'],"  N",$r['price'];?>
                                </option>
                                <?Php
                            }
                                ?>
                    </select>
            </tr>
            </table>
            <input type="submit" name="submit" value="Register Account" />
            <center>
              <p>Already Have An Account ?
              <a href="<?php echo HOST;?>/source/login.php" class="button">Log In</a></p>
            </center>
          </form>
          <?php } ?>
      </div>
    </div>
    <style>#ppbar{background:#CCC;width:400px;height:20px;margin: 5px auto;position: relative;}#pbar{margin:0px;width:0px;background:lightgreen;height: 100%;}#ppbartxt{text-align: right;position: absolute;right: 5px;top: 1px;}</style>
    <?php 
	include "$docRoot/inc/sidemenu.php";
	include "$docRoot/inc/footer.php";
	include "$docRoot/inc/scripts.php";
	?>
    </div>
  </body>
</html>
