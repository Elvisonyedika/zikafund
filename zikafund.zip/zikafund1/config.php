<?php
/* Uncomment the following to display PHP errors */
ini_set("display_errors", "on");

/* Define the Host. No / at the end */
define("HOST", "http://zikafund.plw.ng");

/* Host without protocol (http, https) */
define("CLEAN_HOST", "zikafund.plw.ng");

/* -- Database Configuration STARTS -- */
  
define("DATABASE", serialize(array(
  "host" => "www.plw.ng",
  "port" => 0,
  "name" => "plwng_zikafund",
  "user" => "plwng_zikafund",
  "pass" => "@zikafund11"
)));
    
/* We serialize the DATABASE constant value becuase we can't make arrays as values */
  
/* -- Database Configuration ENDS -- */
?>
