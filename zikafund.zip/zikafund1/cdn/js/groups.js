$("#toInvite").smention("http://localhost/zikafund/source/ajax/getUsers.php",{
  avatar : true,
  width : 300,
  position : "below",
  cache : true,
  after : ", ",
  key : ""
});