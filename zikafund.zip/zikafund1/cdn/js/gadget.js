open.chat = {}; // Register `chat` object
open.chat.lastLoadedUser = 0; // The ID of the user whose messages was last loaded

/* When the chat sidebar is open, other elements shoul be positioned in a way that it wouldn't overlap the sidebar or the other way around : */
/*open.chat.alignOthers = function() {
  if($(window).width() > 720 && $(".usersgt").is(":visible") ){
    $(".content").css("left", "-5%");
  }
};
if(localStorage['chatgtopen'] != 0) {
  open.chat.alignOthers();
}*/ /*****Removed in my debug*****/


/* Scroll the chat window to the last message (to the very bottom) */
open.chat.scrollToEnd = function(){
  if( $('.msgs').length != 0 ){
    $('.msgs').animate({
      scrollTop: $(".msgs")[0].scrollHeight
    }, 1000);
    open.externalLinks($(".msgs"));
  }
};
open.chat.scrollToEnd();

/* A function to check for new messages from server */
open.chat.check = function (type){
  to = $("input[name=to]").length != 0 ? $("input[name=to]").val():"gadget";
  if(type != "gadget"){
    setInterval(function(){
      if(localStorage['onFormSion'] == 0){
        open.checks.init({
          "fl"  : "mC",
          "mC"  : {
            "to"  : to,
            "lid" : $("#"+to+".msgs .msg:last").attr("id")
          }
        }, "yes"); // It's an interval
      }
    }, 7000);
  }
  if(type == "gadget"){
    open.checks.init({
      "fl"  : "mC",
      "mC"  : {
        "to"  : to,
        "all" : "true"
      }
    });
  }
};
$(".msgEditor").smention(open.host + "/ajax/getUsers.php",{
  avatar:true,
  width:300
}).live("keypress",function(e){
  if (e.keyCode == 13 && !e.shiftKey) {
    e.preventDefault();
    $(".chat_form").submit();
  }
});
open.chat.check(); // Check for new messages

/* Open the chat window of user */
$(".usersgt .user").live("click", function(){
  id = $(this)[0].id; // The requested user's ID
  $(".msggt").show();
  $(".msggt input[name=to]").val(id);
  $(".msggt #cwinopen").attr("href", "chat.php?id="+id).text($(this).find(".name").attr("title"));
  $(".chatgt .msgs, .chat_form").attr("id", id);
  if(open.chat.lastLoadedUser != id){
    $("#"+id+".msgs").html("<h3>Initiating Chat...</h3>");
    open.chat.check("gadget");
    $(".msggt .msgEditor").focus();
    open.chat.lastLoadedUser = id; // It was this guy's messages who was last loaded
  }
});

/* Close the user chatbox window */
$(".msggt .close").live("click", function(){
  $(this).parents(".msggt").hide();
});


/* Close the sidemenu */
$("#sidebar-toggled").live("click", function(){
  $("#sidebar").css("left", "-40%");
  $(".swipe-area-left").css("left", "0px");
  $("#sidebar-toggled").css("display", "none");
  $("#sidebar-toggle").css("display", "block");
});

/* Open the sidemenu */
$("#sidebar-toggle").live("click", function(){
  $("#sidebar").css("left", "0");
  $(".swipe-area-left").css("left", "40%");
  $("#sidebar-toggle").css("display", "none");
  $("#sidebar-toggled").css("display", "block");
});

/* Toggle the short profile box */
$("#name_button").live("click",function(){
  $("#short_profile").toggle();
  });
	

/* Mobile Responsive*/
var mq = window.matchMedia("(max-width: 1050px)");
	if(mq.matches){
/* Toggle the chat sidebar*/
$(".content").attr("style", "");
$("#name_button").live("click",function(){
  $(".usersgt").toggle();
  $(".usersgt").css("right", "0px");
  $(".msggt").css("right", "235px");
});
	}
	
/* End of Mobile Responsive*/


