var sc_project = 9454959,
    sc_invisible = 1,
    sc_security = "32cc0826";
window.onload = function(){
 var oHead = document.getElementsByTagName('head').item(0),
     oScript = document.createElement("script");
 oScript.setAttribute("type", "text/javascript");
 oScript.setAttribute("src", "https://secure.statcounter.com/counter/counter.js");
 oHead.appendChild(oScript);
};