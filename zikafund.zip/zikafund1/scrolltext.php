<style style="text/css">
.scroll-up {
 height: 100px;	
 overflow: hidden;
 position: relative;
 color: #06C;
}
.scroll-header h5 {
	margin: 5px;
	text-align:center;
}
.scroll-up p {
 position: absolute;
 width: 100%;
 height: 100%;
 margin: 0;
 line-height: 30px;
 text-align: center;
 font-size:16px;
 /* Starting position */
 -moz-transform:translateX(100%);
 -webkit-transform:translateX(100%);	
 transform:translateX(100%);
 /* Apply animation to this element */	
 -moz-animation: scroll-up 10s linear infinite;
 -webkit-animation: scroll-up 10s linear infinite;
 animation: scroll-up 10s linear infinite;
}
/* Move it (define the animation) */
@-moz-keyframes scroll-up {
 0%   { -moz-transform: translateY(100%); }
 100% { -moz-transform: translateY(-100%); }
}
@-webkit-keyframes scroll-up {
 0%   { -webkit-transform: translateY(100%); }
 100% { -webkit-transform: translateY(-100%); }
}
@keyframes scroll-up {
 0%   { 
 -moz-transform: translateY(100%); /* Browser bug fix */
 -webkit-transform: translateY(100%); /* Browser bug fix */
 transform: translateY(100%); 		
 }
 100% { 
 -moz-transform: translateY(-100%); /* Browser bug fix */
 -webkit-transform: translateY(-100%); /* Browser bug fix */
 transform: translateY(-100%); 
 }
}
</style>

<?php 
var_dump($_SERVER['REQUEST_URI']);
if ($_SERVER['REDIRECT_PAGE'] == "sidemenu.php"){
	?>
/** For Sidemenu only **/
<div class="scroll-header">
 <h5>As a Professional</h5>
 </div>
<div class="scroll-up">
<p>
  Teach for Cash</br>
  Build Your Connection</br>
  Job Opportunities</br>
  Inspire Others
</p>
</div>
<div class="scroll-header">
 <h5>As a Student</h5>
 </div>
<div class="scroll-up">
<p>
  Teach for Cash</br>
  Build Your Connection</br>
  Job Opportunities</br>
  Inspire Others
</p>
</div>
<div class="scroll-header">
 <h5>As a Company</h5>
 </div>
<div class="scroll-up">
<p>
  Teach for Cash</br>
  Build Your Connection</br>
  Job Opportunities</br>
  Teach for Cash</br>
  Build Your Connection</br>
  Job Opportunities</br>
  Teach for Cash</br>
  Build Your Connection</br>
  Job Opportunities</br>
  Inspire Others
</p>
</div>
<?php } ?>