<header>

<a class id="sidebar-toggle" href="javascript:;">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
     </a>
     <a class id="sidebar-toggled" href="javascript:;">
         <span class="close" style="font-size:70px; margin: 15px -30px;position: absolute;">X</span>   
     </a>

  <div class="logo">
    <a style="text-decoration:none;" href='<?php echo HOST;?>/'>
    <h1>ZIKAFUND</h1><h6 style="margin-top:-12%; float:right; width:140px"><center>P2P NETWORK</center></h6>
    </a>
  </div>
  <nav <?php if(loggedIn){?> style="right:12%;"<?php }?>>
  		 <ul>
         	<?php if(loggedIn){
		if($who == 22 || $who == 36){?>
            <li><a href="<?php echo HOST;?>/source/admin.php">Admin</a></li>
		<?php }?>
            <li><a href="<?php echo HOST;?>">Dashboard</a></li>
            <li><a href="<?php echo HOST;?>/source/transactions.php">Transactions</a></li>
            <li><a href="<?php echo HOST;?>/source/referrals.php">Referrals</a></li>
            <li><a href="<?php echo HOST;?>/source/contact.php">Support</a></li>
        	<?php } else {?>
            <li><a href="<?php echo HOST;?>">Home</a></li>
            <li><a href="<?php echo HOST;?>/source/about.php">About Us</a></li>
            <li><a href="<?php echo HOST;?>/source/contact.php">Contact Us</a></li>
            <li><a href="<?php echo HOST;?>/source/how-it-works.php">How It Works</a></li>
            <li><a href="<?php echo HOST;?>/source/login.php
				<?php
        			if( isset($_SERVER['REQUEST_URI']) ){ 
          			if( $_SERVER['REQUEST_URI'] != "/" && !preg_match("/\/login/", $_SERVER['REQUEST_URI']) ){
           			echo "?c=";
            		echo $_SERVER['REQUEST_URI'];
         			 	}
       				 }
				?>">Login</a>
        	</li>
            <li><a href="<?php echo HOST;?>/source/register.php">Register</a></li>
        </ul>
  <?php }?>
  </nav>
  <?php if(loggedIn){ ?>
    <div class="curuserinfo">
      <button id="name_button" class="button b-white" who="<?php echo $who;?>"><img src="<?php echo get("avatar")?>" width="30px" height="30px"/> </br><?php echo get("fname");?></button>
      <div id="short_profile" class="c_c">
          <a href="<?php echo HOST;?>/source/me" class="button" style="position:absolute; width:100%; left:-5px; border-top-left-radius:1em; border-top-right-radius:1em;">Manage Account</a></br>
          <a href="<?php echo HOST;?>/source/login.php?logout=true" class="button b-red" style="position:absolute;width:100%;bottom: 0px;left:-5px; border-bottom-left-radius:1em; border-bottom-right-radius:1em;">Log Out</a>
      </div>
    </div>
    <div class="notifications">
      <?php
      $sql = $OP->dbh->prepare("SELECT COUNT(`red`) FROM `notify` WHERE `red`='0' AND `uid`=?");
      $sql->execute(array($who));
      $count = $sql->fetchColumn();
      $count = $count == "" ? 0 : $count;
      ?>
      <a id="nfn_button" class="button b-white" <?php echo $count == 0 ? "" : "b-red";?>"><img src="<?php echo HOST;?>/cdn/img/nfn.png" width="20px" height="25px"/> </br><?php echo $count;?></a>
        <div id="nfn" class="c_c">
        	<div class="top">Notifications</div>
            <center class="loading"><br/><br/><img src="<?php echo HOST. "/cdn/img/load.gif";?>"/><br/>Loading</center>
          <div class="nfs"></div>
        </div>
     </div>
  <?php }?>
</header>
