<?php
/* O.V.B.S 29 April 2014 */
class Ec extends Open {
  private $cU;
  public function getDetails($user=null){
    if($user != null){
      $this->cU = $user;
	  
	  //this returns an array; I need just an element of that array
	  $uDetails = $this->uDetails();
	  $uName = $uDetails['uName'];
	  $uPhone = $uDetails['uPhone']; 
	  $email = $uDetails['email'];
	  $bName = $uDetails['bName'];
	  $accName = $uDetails['accName']; 
	  $accNo = $uDetails['accNo'];
	  
      return array(
		"uName" => $uName,
		"uPhone" => $uPhone,
		"email" => $email,
		"bName" => $bName,
		"accName" => $accName,
		"accNo" => $accNo,
      );
    }
  }

  /*Get the number of referrals for the user*/
  private function uDetails(){
	/*Get the users details*/
	$sql = $this->dbh->prepare("SELECT * FROM `users` WHERE `id`= ?");
    $sql->execute(array($this->cU));
    $udata = $sql->fetchAll(PDO::FETCH_ASSOC);
	
	/*Get the users bank_details*/
	$sql = $this->dbh->prepare("SELECT * FROM `bank_details` WHERE `uid`= ? ORDER BY `id` DESC LIMIT 1");
    $sql->execute(array($this->cU));
    $bdata = $sql->fetchAll(PDO::FETCH_ASSOC);
	  
	$uName = $udata[0]['name'];
	$uPhone = $udata[0]['phone'];
	$email = $udata[0]['username'];
	$bName = $bdata[0]['Bank'];
	$accName = $bdata[0]['Acc_name'];
	$accNo = $bdata[0]['Acc_no'];

    $uDetails = array(
		"uName" => $uName,
		"uPhone" => $uPhone,
		"email" => $email,
		"bName" => $bName,
		"accName" => $accName,
		"accNo" => $accNo,
	);
	return $uDetails;
  }

  /*Return numbers in given decimal places*/
  private function roundNum($number, $precision = 2){
	  //Handle zero value
	  if (0==(int)$number){
		  return sprintf('%0.2f', $number);
		  }
	  //Handle negetive value
	  $negative = $number/abs($number);
	  //Cast the number to a positive to solve rounding
	  $number = abs($number);
	  //Calculate precision number for dividin / multiplying
	  $precision = pow(10, $precision);
	  //Return the answer; re-apply negative or positive
	  return sprintf('%0.2f', floor ($number * $precision)/$precision * $negative);
	  }
	
	
	/*This funtion formats time to hours:mis:secs*/
	public function gettimeDiff($t,$f=':'){
		return ($t<0? '-' : '') . sprintf("%02d%s%02d%s%02d", 
		floor(abs($t)/3600), $f, (abs($t)/60)%60,$f, abs($t)%60);
		}
		
   /*This funtion converts one currency to another*/
   public function createOrder($who, $pkID, $rInv, $rInv){
	   /* Create the order */
	   $this->openPK($who,$pkID, $rInv, $rInv);
			
		/* Get the ID of the order */				
	   $sql = $this->dbh->prepare("SELECT * FROM `activations` WHERE `uID` = ? ORDER BY `id` DESC LIMIT 1");
	   $sql->execute(array($who));
	   
	   $orderArr = $sql->fetchAll(PDO::FETCH_ASSOC);
	   $oID = $orderArr[0]['id'];
	   
	   /* Match user to pay someone already activated */
	   $this->matchOrders($oID,$pkID,$who);
	   /* Notify the user */
	   return true;
   }
   
   /*Create the bonus*/
  private function openPK($who, $pkID, $rInv, $rInv){
  	$nemife = array(1,2,3,4,5,6,7,8,9,10);
  	if (in_array($who,$nemife)){$statusID = 3;}else{$statusID = 1;}
    $sql = $this->dbh->prepare("INSERT INTO `activations` (
	   `uID`, `pkID`, `rInv`, `bal`, `statusID`, `created`)
	    VALUES (?, ?, ?, ?, ?, now())");
	$sql->execute(array($who, $pkID, $rInv, $rInv,$statusID));
    return true;
  }
  
  public function matchOrders($Oid,$pkID,$who){
	  /*Get an activated acount*/
    $sql = $this->dbh->prepare(
			"SELECT * FROM `activations` 
			WHERE `statusID` IN (3,4) AND `pkID`= ? AND `uID` != ? 
			ORDER BY `id` DESC LIMIT 1");
    $sql->execute(array($pkID,$who));
	if ($sql->rowCount() == 0){ /*No body to be merged with so merge with nemife*/
    $sql = $this->dbh->prepare(
			"SELECT * FROM `activations` 
			WHERE `uID` IN (1,2,3,4,5,6,7,8,9,10) AND `pkID`= ? AND `uID` != ? 
			ORDER BY `id` DESC LIMIT 1");
    $sql->execute(array($pkID,$who));
	if ($sql->rowCount() == 0){ 
		/*Exit script if no active order exist 
		**(This is to allow the first person to create account without being matched)*/
		return false;
		}
	}
    $s = $sql->fetch();
    	$rOid = $s['id'];
		$rID = $s['uID'];
		$Amount = $s['rInv'] / 2;
		$Bal = $s['bal'] - $Amount;
		
		/*Create the matchOrder*/
		$this->createTrans($who, $Oid, $rID, $rOid, $Amount,$Bal);
		
    		return true;
  }
  

  /*Create matchOrder*/
  private function createTrans($sID, $sOid, $rID, $rOid, $Amount,$Bal){
	  	$created = date('Y-m-d H:i:s');
		$ending =  date('Y-m-d H:i:s', strtotime('+12 hours'));
		$sql = $this->dbh->prepare("INSERT INTO `transactions` (
			`sID`, `soID`,`rID`, `roID`, `amount`,`created`, `ending`, 
			`closed`, `statusID`, `sProve`)
			 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$sql->execute(array(
			$sID, $sOid, $rID, $rOid, $Amount, $created, $ending,
			"", 1, ""));
			
		/*Update order balances activation status*/
		$stID = $Bal > 0 ? 4 : 5;
		$sql = $this->dbh->prepare("UPDATE `activations` SET `bal`= ?, `statusID`= ? WHERE `id`=? AND `uID`= ?");
		$sql->execute(array($Bal, $stID, $rOid, $rID));

    return true;
  }
  
  
/*Create or activate the bonus the bonus*/
  public function createRefBonus($uID = 0, $refID, $statusID = 0){
	  if ($statusID = 6){
		  $sql = $this->dbh->prepare("UPDATE `ref_bonus` SET `statusID`= 1 WHERE `refID`=? AND `uID`= ?");
		$sql->execute(array($refID, $uID));
		  }else{
    $sql = $this->dbh->prepare("INSERT INTO `ref_bonus` (
			`uID`, `refID`, `statusID`, `amount`, `created`)
			 VALUES (?, ?, ?, ?, ?)");
	$sql->execute(array($uID, $refID, 0, 1000, now()));
	}
    return true;
  }
  
  public function refBonus($who){
  	$sql = $this->dbh->prepare("SELECT SUM(`amount`) FROM `ref_bonus` WHERE `uID`=:who AND `statusID` = 0");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$avBal = $sql->fetchColumn();
	
	$sql = $this->dbh->prepare("SELECT SUM(`amount`) FROM `ref_bonus` WHERE `uID`=:who AND `statusID` IN (0,1)");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$bkBal = $sql->fetchColumn();
	$bkBal = $bkBal + $avBal;
	
	$sql = $this->dbh->prepare("SELECT SUM(`amount`) FROM `ref_bonus` WHERE `uID`=:who AND `statusID` = 2");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$paidBonus = $sql->fetchColumn();
	
	$bals = array(
		"avBal" => $this->roundNum($avBal),
		"bkBal" => $this->roundNum($bkBal),
		"paidBonus" => $this->roundNum($paidBonus)
	);
	return $bals;
  }
  
  
    public function uBal($who){
  	$sql = $this->dbh->prepare("SELECT SUM(`bal`) FROM `activations` WHERE `uID`=:who AND `statusID` IN (2,3,4,5)");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$avBal = $sql->fetchColumn();
	
	$sql = $this->dbh->prepare("SELECT SUM(`amount`) FROM `transactions` WHERE `rID`=:who AND `statusID` IN (1,8)");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$Bal = $sql->fetchColumn();
	
	$bkBal = $avBal + $Bal;
	
	$sql = $this->dbh->prepare("SELECT SUM(`amount`) FROM `transactions` WHERE `rID`=:who AND `statusID` = 6");
    $sql->bindValue(':who', $who);
    $sql->execute();
	$paidOut = $sql->fetchColumn();
	
	$bals = array(
		"avBal" => $this->roundNum($avBal),
		"bkBal" => $this->roundNum($bkBal),
		"paidOut" => $this->roundNum($paidOut)
	);
	return $bals;
  }
  

  public function upDate($tID, $rIndic, $sostID, $tstID, $closed,$sProve){
	  /*Get an activated acount*/
    $sql = $this->dbh->prepare(
			"SELECT * FROM `transactions` 
			WHERE `id` = ? 
			ORDER BY `id` DESC LIMIT 1");
    $sql->execute(array($tID));
	if ($sql->rowCount() == 0){ 
		/*Exit script if no active order exist 
		**(This is to allow the first person to create account without being matched)*/
		return false;
	}else{
		/*Extract sender's and recievers ID*/
		$r = $sql->fetch();
		$sID = $r['sID'];
		$soID = $r['soID'];
		$roID = $r['roID'];
		/*Get recievers details and calculate metrics*/
		$sql = $this->dbh->prepare("SELECT * FROM `activations`WHERE `id` = ?");
    	$sql->execute(array($roID));
		$r = $sql->fetch();
		$rostID = $r['statusID'];
		$rInv = $r['rInv'];
		$bal = $r['bal'];
		if ($rIndic == -1){/*Return deducted money for cancelled or purged order and reset status*/
			$bal = $bal + ($rInv/2);
			$rostID = $rostID - 1;
			}
		//if ($rostID = 5 && ($rIndic == -1 || $rIndic == 0)){$rostID = 6;}
		/*Update transaction*/
		$sql = $this->dbh->prepare("UPDATE `transactions` SET `statusID`= ?, `closed`= ?, `sProve`= ? WHERE `id`=?");
    	$sql->execute(array($tstID,$closed,$sProve,$tID));
		/*Update sender's order*/
		$sql = $this->dbh->prepare("UPDATE `activations` SET `statusID`= ?, `closed`= ? WHERE `id`=?");
    	$sql->execute(array($sostID,$closed,$soID));
		return $sID;
		/*Update reciever's order*/
		if ($rostID != 6){$closed = "";}
		$sql = $this->dbh->prepare("UPDATE `activations` SET `statusID`= ? , `bal`= ?, `closed`= ? WHERE `id`=?");
    	$sql->execute(array($rostID,$bal,$closed,$roID));
	}
  }
  
  
  public function getStatus($statusID){
	 $sql = $this->dbh->prepare("SELECT `name` FROM `status` WHERE `id` = ?");
          			  $sql->execute(array($statusID));
					  $status = $sql->fetch();
					  $status = $status[0];
		return $status;
	}
  
}
?>