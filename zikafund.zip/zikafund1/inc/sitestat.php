<?php
if($_SERVER['REQUEST_URI']=="/"){
require_once "load.php";
}else{
require_once "../load.php";
}
$comment_query=$OP->dbh->prepare("select * from comments ");
$comment_query->execute();
	$countA=$comment_query->rowCount();

$post_query=$OP->dbh->prepare("select * from posts ");
$post_query->execute();
	$countP=$post_query->rowCount();
	
$users_query=$OP->dbh->prepare("select * from users ");
$users_query->execute();
	$countU=$users_query->rowCount();	

?>
<center>
 Our Statistics So Far <br/>
 Users     : <?php echo $countU; ?> <br/>
 Questions : <?php echo $countP; ?><br/>
 Answers   : <?php echo $countA; ?>
</center>