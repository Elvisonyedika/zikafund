<?php if(loggedIn){
	$rdURL= '../inc/order.php';
		if ($statusID == 1){ //You have been merged to pay
			$txt1 = "<h2>You have been merged to donate</h2>";
			$txt2 = "Please Pay The Person Below.";
			$txt3 = "<h2 style='border-bottom:0px;margin-bottom:-30px;'>YOU HAVE</h2></br>
			<h2 id='t' style='border-bottom:0px; text-transform: none; color:red;margin-bottom:-30px;'></h2></br>
			<h2>TO MAKE PAYMENT</h2>";
			$txt4 = "Paid";
			$txt5 = "Decline";
			$txt6 = "Awaiting Payment";
			}else if ($statusID == 2){ //You have paid but awaits confirmation
				$txt1 = "<h2>You will be activated soon</h2>";
				$txt2 = "Please Wait Patiently To Be Activated.";
				$txt3 = "<h2 id='t' style='display:none;'></h2>
				<h2 style='border-bottom:0px;margin-bottom:-30px;'>If this takes too long</h2></br>
				<h2 style='border-bottom:0px; text-transform: none; color:red;margin-bottom:-30px;'>
				Call Your Sponsor Below</h2></br>
				<h2>or open a support ticket</h2>";
				$txt4 = "Paid";
				$txt5 = "Decline";
				$txt6 = "Awaiting Confirmation";
				}else if (($statusID == 3 || $statusID == 4) && $activeTRANS==0){ //Confirmed and await match
					$txt1 = "<h2>You have been activated</h2>";
					$txt2 = "Please Wait Patiently To Be Merged.";
					$txt3 = "<h2 id='t' style='display:none;'></h2>
					<h2 style='border-bottom:0px;margin-bottom:-30px;'>You should be Merged</h2></br>
					<h2 style='border-bottom:0px; text-transform: none; color:red;margin-bottom:-30px;'>SOON</h2></br>
					<h2>Please be patient</h2>";
					}else if (($statusID == 4 || $statusID == 5) 
					&& $activeTRANS>0 && $tStatusID ==1){//Confirmed and matched. Awaiting payment
						$txt1 = "<h2>You Have Been Merged to be Paid</h2>";
						$txt2 = "You Will Be Paid Soon!.";
						$txt3 = "<h2 id='t' style='border-bottom:0px; 
						text-transform: none; color:red;margin-bottom:-30px;'></h2></br>
						<h2>Please don't forget to confirm</br>Cash Reception Once You are Paid</h2>";
						$txt4 = "Confirm";
						$txt5 = "Purge";
						$txt6 = "Awaiting Payment";
						}else if (($statusID == 4 || $statusID == 5) 
							&& $activeTRANS>0 && $tStatusID ==2){//Confirmed and matched. Awaiting payment
							$txt1 = "<h2>You Have Been Paid</h2>";
							$txt2 = "Please Confirm The Person Below";
							$txt3 = "<h2 id='t' style='display:none;'></h2><h2 style='border-bottom:0px; 
							text-transform: none; color:red;margin-bottom:-30px;'>If The Prove Uploaded is fake</h2></br>
							<h2>Just Click The Purge Button</br>And We will attend to your case</h2>";
							$txt4 = "Confirm";
							$txt5 = "Purge";
							$txt6 = "Awaiting Confirmation";
								}else { //You don't have an active order
								$txt1 = "<h2>Your Cycle Of Donation Is Complete</h2>";
								$txt2 = "You Can Recycle Now!.";
								$txt3 = "<h2 style='border-bottom:0px;margin-bottom:-30px;'>
								Your Account Will Be Blocked In</h2></br>
								<h2 id='t' style='border-bottom:0px; text-transform: none; color:red;margin-bottom:-30px;'>
								</h2></br><h2>If you don't recycle</h2>";
								}
								
	?>
<div class="icontent" style="background:white;">
	<center><div class="heading text-center" style="color:green;">
		<?php echo $txt1; ?>
	</div>
      <p class="lead">
          <?php echo $txt2; ?>
      </p>
    <div class="heading text-center" style="color:green;">
		<?php echo $txt3; ?>
	</div>
   </center>	
</div>
<?php }else {$rdURL= 'source/register.php';}?>
<?php if( isset($activeTRANS) && $activeTRANS > 0 ){ ?>
<div class="row packages">
  <div class="col-md-12">
    <div class="package">
      <div class="package-header">
          <h5><?php echo $txt6; ?></h5>
      </div>
      <div class="price">
         <div class="price-container">
            <h4 style="font-size: 28px;">
            	AMOUNT:
               <span class="currency">N</span>
                   <?php echo $amount;?>
            </h4>
         </div>
      </div>
		<form>
          <table>
          	<tr <?php if (($statusID == 4 || $statusID == 5) && $activeTRANS > 0){echo "style='display:none;'";}?>>
          		<th style="width:25%">
            <part>Bank Name</part>
            	</th>
                <th style="width:25%">
            <part>Account Name</part>
            	</th>
                <th style="width:25%">
            <part>Account Number</part>
            	</th>
            </tr>
            
            <tr <?php if (($statusID == 4 || $statusID == 5) && $activeTRANS > 0){echo "style='display:none;'";}?>>
          		<th style="width:25%">
            		<input class="details" type="text" value="<?php echo $ubank;?>" disabled="disabled">
            	</th>
                <th style="width:25%">
            		<input class="details" type="text" value="<?php echo $uAccName;?>" disabled="disabled">
            	</th>
                <th style="width:25%">
                	<input class="details" type="text" value="<?php echo $uAccNo;?>" disabled="disabled">
            	</th>
            </tr>
            
            <tr>
          		<th style="width:25%">
            <part>Name</part>
            	</th>
                <th style="width:25%">
            <part>Phone</part>
            	</th>
                <th style="width:25%">
            <part>Email</part>
            	</th>
            </tr>
            
            <tr>
          		<th style="width:25%">
            		<input class="details" type="text" value="<?php echo $uname;?>" disabled="disabled">
            	</th>
                <th style="width:25%">
            		<input class="details" type="text" value="<?php echo $uphone;?>" disabled="disabled">
            	</th>
                <th style="width:25%">
                	<input class="details" type="text" value="<?php echo $uemail;?>" disabled="disabled">
            	</th>
            </tr>
          </table>
        </form>
    <?php 
	if ($txt4 == "Paid"){
	echo "<a id='order' name='$tID?$soID?$tStatusID' class='button b-green'>$txt4</a>";
	}else {
		echo "<a id='y' href='$rdURL?val=$txt4?$tID' class='button b-green'>$txt4</a>";
		}
	
	if (($txt5 == "Decline" && $tStatusID != 2)||($txt5 == "Purge" && $timeVal < 0) || ($tStatusID == 2 && $sID !== $who)){
		echo "<a id='n' href='$rdURL?val=$txt5?$tID?$tStatusID' class='button b-red'>$txt5</a>";
	}else {
		echo "<a id='n' class='button b-red'>$txt5</a>";
		}
	?>
	  </div>
    </div>
  </div>
<?php } else if( !loggedIn || (isset($activePK) && $activePK == 0)){?>
				<div class="row">
                	<div class="col-md-12">
                    	<center><div class="heading text-center">
                        <h2>Packages We Offer</h2>
                        </div>
                        	<p class="lead">
                            	Select the appropriate package that suites you.
                            </p>
                        </center>
                        <div class="row packages">
                        	<div class="col-md-15">
                            	<div class="package">
                                	<div class="package-header">
                                    	<h5>Coral</h5>
                                    </div>
                                    <div class="price">
                                    	<div class="price-container">
                                        	<h4 style="font-size: 32px;">
                                            	<span class="currency">N</span>
                                            	10,000
                                            </h4>
                                        </div>
                                    </div>
                                    <ul>
                                    	<li>
                                        	<i class="fa fa-check"></i>
                                            2:1 Matrix
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Auto Assign
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Referral Bonus
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            N20,000 Return Investment
                                        </li>
                                    </ul>
                         	<a href="<?php echo $rdURL;?>?pkID=1" class="button b-green">Activate</a>
                                </div>
                            </div>
                            <div class="col-md-15">
                            	<div class="package">
                                	<div class="package-header">
                                    	<h5>Ruby</h5>
                                    </div>
                                    <div class="price">
                                    	<div class="price-container">
                                        	<h4 style="font-size: 32px;">
                                            	<span class="currency">N</span>
                                            	20,000
                                            </h4>
                                        </div>
                                    </div>
                                    <ul>
                                    	<li>
                                        	<i class="fa fa-check"></i>
                                            2:1 Matrix
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Auto Assign
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Referral Bonus
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            N40,000 </br>
                                            Return Investment
                                        </li>
                                    </ul>
                            <a href="<?php echo $rdURL;?>?pkID=2" class="button b-green">Activate</a>
                                </div>
                            </div>
                            <div class="col-md-15">
                            	<div class="package">
                                	<div class="package-header">
                                    	<h5>Sapphire</h5>
                                    </div>
                                    <div class="price">
                                    	<div class="price-container">
                                        	<h4 style="font-size: 32px;">
                                            	<span class="currency">N</span>
                                            	50,000
                                            </h4>
                                        </div>
                                    </div>
                                    <ul>
                                    	<li>
                                        	<i class="fa fa-check"></i>
                                            2:1 Matrix
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Auto Assign
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Referral Bonus
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            N100,000 </br>
                                            Return Investment
                                        </li>
                                    </ul>
                            <a href="<?php echo $rdURL;?>?pkID=3" class="button b-green">Activate</a>
                                </div>
                            </div>
                            <div class="col-md-15">
                            	<div class="package">
                                	<div class="package-header">
                                    	<h5>Emerald</h5>
                                    </div>
                                    <div class="price">
                                    	<div class="price-container">
                                        	<h4 style="font-size: 32px;">
                                            	<span class="currency">N</span>
                                            	100,000
                                            </h4>
                                        </div>
                                    </div>
                                    <ul>
                                    	<li>
                                        	<i class="fa fa-check"></i>
                                            2:1 Matrix
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Auto Assign
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Referral Bonus
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            N200,000 </br>
                                            Return Investment
                                        </li>
                                    </ul>
                            <a href="<?php echo $rdURL;?>?pkID=4" class="button b-green">Activate</a>
                                </div>
                            </div>
                            <div class="col-md-15">
                            	<div class="package">
                                	<div class="package-header">
                                    	<h5>Diamond</h5>
                                    </div>
                                    <div class="price">
                                    	<div class="price-container">
                                        	<h4 style="font-size: 32px;">
                                            	<span class="currency">N</span>
                                            	200,000
                                            </h4>
                                        </div>
                                    </div>
                                    <ul>
                                    	<li>
                                        	<i class="fa fa-check"></i>
                                            2:1 Matrix
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Auto Assign
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            Referral Bonus
                                        </li>
                                        <li>
                                        	<i class="fa fa-check"></i>
                                            N400,000 </br>
                                            Return Investment
                                        </li>
                                    </ul>
                            <a href="<?php echo $rdURL;?>?pkID=5" class="button b-green">Activate</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php }?>
