<!doctype html>
<html>
	<head>
		<style>*{font-family:ubuntu;}</style>
	</head>
	<body>
    
    <h1><center><strong>Terms & Conditions</strong></center></h1>
You are responsible for your use of the services, for any Questions you ask and answers you provide, and for any consequences thereof. The Questions you ask, and Answers you provide will be able to be viewed by other users of the services.
You may use the Services only if you can form a binding contract with PLW and are not a person barred from receiving services under the laws of the United States or other applicable jurisdiction. If you are accepting these Terms and using the Services on behalf of a company, organisation, government, or other legal entity, you represent and warrant that you are authorized to do so.  You may use the Services only in compliance with these Terms and all applicable local, state, national, and international laws, rules and regulations.
You can only join PLW if you agree to our terms. If you break any rule or disobey the policies of PLW then you might be banned or removed from PLW.
You can only join PLW if you're 13 or over 13. We will not ask for your birthday in the signup process, because you can only signupo if you have an EMail. E­Mail accounts are only available for specific age groups. In some cases, your account will be removed or blocked when you don't use PLW by its rules and regulations. If your account has been blocked or removed then you should not create another account. By giving us your E­Mail, you are acknowledging that PLW will send you EMails. The E­Mails sent will not contain SPAM, Advertisements or other malicious things.
There is no restriction in contributing to PLW. You can contribute as you like. By signing up, it doesn't mean that you should contribute. It's your decision whether you contribute or not.
This document's laws and conditions are applicable to every individual / organisation who has signed up for using the PLW Network.

<h1><center><strong>Safety</strong></center></h1>
We will do our best to keep PLW safe, convenient and palatable for your use but we cannot guarantee that. We need your help to keep PLW safe, which includes the following commitments by you:<br/>

1.	You will not post unauthorized commercial communications (such as spam) on PLW.<br/>
 
2.	You will not collect users' content or information, or otherwise access PLW, using automated means (such as harvesting bots, robots, spiders, or scrapers) without our prior permission.<br/>

3.	You will not engage in unlawful multi­level marketing, such as a pyramid scheme, on PLW.<br/>

4.	You will not upload viruses or other malicious code.<br/>

5.	You will not solicit login information or access an account belonging to someone else.<br/>

6.	You will not bully, intimidate, or harass any user.<br/>

7.	You will answer users’ questions with respect and understanding. No vulgar languages will be used.<br/>

8.	You must understand that users are from different regions of the world and may have divers level of command of some languages.<br/>

9.	You will not post content that is: hating speech, threatening, or pornographic; incites violence; or contains nudity or graphic or gratuitous violence.<br/>

10.	You will not develop or operate a third-party application containing alcohol related, dating or other mature content (including advertisements).<br/>

11.	You will not use PLW to do anything unlawful, misleading, malicious, or discriminatory.<br/>

12.	You will not do anything that could disable, overburden, or impair the proper working or appearance of PLW, such as a denial of service attack or interference with page rendering or other PLW functionality.<br/>

13.	You will not facilitate or encourage any violations of this Statement or our policies.<br/>

<h1><center><strong>Your Data</strong></center></h1>
The data you give us are stored and protected in our databases. The database is only accessbile to us and the hosting provider. No one else has access to it. Hence your data is not stolen. Your E­Mail and Name is only given to 3rd party companies for mailing newsletters, account information etc... The 3rd party companies are Mailchimp and Mailgun. They protect their data like any other websites. You should know about this when using PLW.
<div style="float:right;"><p>Last Updated on 30/06/2016</p></div>


	</body>
</html>