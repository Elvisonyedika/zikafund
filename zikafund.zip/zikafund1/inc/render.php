<?php
class Render {
  
  /**
   * The $single variable is for displaying a single message. It should contain the message ID.
   */
  public static function chat($fid, $single = false){
	  $FName = get("name", $fid, false); // Name of person to chat with
    global $OP;
    if($single === false || $single === true){
      $sql = $OP->dbh->prepare("SELECT * FROM (SELECT * FROM `chat` WHERE (`uid` = :who AND `fid` = :fid) OR (`uid` = :fid AND `fid` = :who) ORDER BY id DESC LIMIT 15) sub ORDER BY `id` ASC");
      $sql->execute(array(
        ":who" => curUser,
        ":fid" => $fid
      ));
    }elseif($single !== true){
      $sql = $OP->dbh->prepare("SELECT * FROM `chat` WHERE `id` = ?");
      $sql->execute(array($single));
    }
    $html = "";
    if($single == false){
      $html = "<div class='msgs' id='$fid'>";
    }
    if($sql->rowCount()!=0){
      while($r = $sql->fetch()){
        $mid = $r['id']; // Message ID
        $uid = $r['uid']; // User ID
        $img = get("avatar", $uid); // Avatar Image
        $name = get("name", $uid, false); // Name
        $pLink = get("plink", $uid); // Profile URL
        $fName = get("fname", $uid); // First Name
        $html  .= "<div class='msg' id='$mid'>";
        if($uid == curUser){
          $html.="<div class='left'>";
            $html.="<div class='mainContent'>";
              $html.="<div class='up'>";
                $html.="<a target='_blank' href='$pLink' title='{$name}'>{$fName}</a>";
                $html.="<span class='time'>{$r['posted']}</span>";
              $html.="</div>";
              $html.="<div class='cmsg'>{$r['msg']}</div>";
            $html.="</div>";
            $html.="<div class='avatar'>";
              $html.="<a target='_blank' href='$pLink'>";
                $html.="<img height='32' width='32' src='$img'>";
              $html.="</a>";
            $html.="</div>";
          $html.="</div>";
        }else{      
          $html.="<div class='right'>";
            $html.="<div class='mainContent'>";
              $html.="<div class='up'>";
                $html.="<a target='_blank' href='$pLink'>$fName</a>";
                $html.="<span class='time'>{$r['posted']}</span>";
              $html.="</div>";
              $html.="<div class='cmsg'>{$r['msg']}</div>";
            $html.="</div>";
            $html.="<div class='avatar'>";
              $html.="<a target='_blank' href='$pLink'>";
                $html.="<img height='32' width='32' src='$img'>";
              $html.="</a>";
            $html.="</div>";
          $html.="</div>";
        }
        $html.="</div>";
      }
    }else{
      $html.="<h2>No Messages</h2>You haven't exchanged messages with {$FName}. Spark up a conversation.";
    }
    if( !$single ){
      $html.="</div>";
    }
    if( !$single ){
      $html .= "<form action='ajax/msg.php' method='POST' class='ajax_form chat_form blocks' id='$fid' success='Sent Successfully' error='Sending Failed. Try again.' while='Sending'>";
        $html .= "<input type='hidden' name='to' value='$fid'/>";
        $html .= "<textarea type='text' class='msgEditor' name='msg' style='font-size: 14px;'></textarea>";
        $html .= "<input type='submit' name='submit' value='Send' style='width:70px; float: right; font-size: 14px;'/>";
      $html .= "</form>";
    }
    $sql = $OP->dbh->prepare("UPDATE `chat` SET `red`='1' WHERE `uid`=? AND `fid`=? AND `red`='0'");
    $sql->execute(array($fid, curUser));
    return $html;
  }
  
  public static function post($postArr) {
    global $OP;
     $html = "";
    if(count($postArr) == 0){
        $html = "<h2><center>No Post/Questions Found</center></h2>";
    }else{
      /* $v contains information about the post*/
      foreach($postArr as $v){
        $owner = $v['uID']; /* The user ID of the post owner */
        $id = $v['id']; /* The Post ID */
		/* Get the subject */
		$subject = $v['subject'];
			if ($v['replies'] == 1){ $badge = "Reply";}else {$badge = "Replies";}
		$post = $v['message'];
        $otherSTR = false;

        if( strlen($post) > 500 ){
          $postSplit = str_split($post, 500);
          $post = $postSplit[0];
          $otherSTR = str_replace($post, "", $v['message']); // The left post
          $otherSTR = $OP->format($otherSTR, true);
        }
        
		$text = "Post";
        /* We format the post from @1 to @Subin Siby */
        $post = $OP->format($post, true);
        
        /* The Profile Link */
        $plink = get("plink", $owner);
  
          $html .= "<div class='post blocks' id='$id'>";
          $html .= "<div class='left block'>";
              $html .= "<img src='".get("avatar", $owner)."' class='pimg'/>";
          $html .= "</div>";
          $html .= "<div class='right block'>";
              $html .= "<div class='top'>";
                 $html .= get("name", $owner, false);
                 $html .= "<a class='time slink'>{$v['created']}</a>";
                 $html .= "<span class='privacy slink' title='Only you and Admin can see this {$text}'>{$subject}</span>";
            if($owner == curUser){
                  $html .= "<div class='author_box'>";
                $html .= "<div class='author_panel c_c'>";
                  $html .= "<a class='editPost pointer'>Edit {$text}</a><cl/>";
                  $html .= "<a class='deletePost pointer'>Delete {$text}</a><cl/>";
                  $html .= "<a class='postLink pointer'>HyperLink</a>";
                $html .= "</div>";
              $html .= "</div>";
            }
              $html .= "</div>";
              $html .= "<div class='cont'>";
                 if( $otherSTR ){
                $html .= $post . "<a class='button b-green readMore'>Read More <div hide>{$otherSTR}</div></a>";
              }else{
                $html .= $post;
              }
              
              $html .= "</div>";
              $html .= "<div class='bottom'>";
                 $html .= "<div class='cmt_bar'><a class='pst cmt' id='$id'>Comment</a><span class='count ck' id='$id'>{$v['replies']} {$badge}</span></div>";
                 $html .= self::comment($id);
              $html .= "</div>";
          $html .= "</div>";
          $html .= "</div>";
      }
    }
    return   $html;
  }
  
  public static function comment($pid) {
    global $who, $OP;
 
    $postCMTcount = $OP->dbh->prepare("SELECT `pid` FROM `comments` WHERE `pid`=?");
    $postCMTcount->execute(array($pid));
    $postCMTcount = $postCMTcount->rowCount();
 
    if(!isset($_POST['all'])){
      $sql = $OP->dbh->prepare("SELECT * FROM `comments` WHERE `pid`=? ORDER BY `id` DESC LIMIT 2");
    }else{
      $sql = $OP->dbh->prepare("SELECT * FROM `comments` WHERE `pid`=? ORDER BY `id` DESC");
    }
    $sql->execute(array($pid));
 
     $html = "<div class='comments' id='$pid'>";
		$text1 = "Reply"; $text2 = "Replied"; $text3 = "Ticket";
		
	  $html .= "<form class='cmt_form ajax_form' id='$pid' action='ajax/comment.php' success='{$text1}ed' error='Failed To {$text1}' while='{$text1}ining'>";
        $html .= "<input type='hidden' id='clod' name='clod' value='0'/>";
        $html .= "<textarea name='cmt' type='text' class='textEditor' placeholder='Your {$text1} Here'></textarea>";
        $html .= "<input name='id' type='hidden' value='$pid'/>";
        $html .= "<button class='b-green'>{$text1}</button>";
      $html .= "</form>";
      if($sql->rowCount() != 0){
       while( $r = $sql->fetch() ){
        $id = $r['id'];
        $uid = $r['uid'];
        $img = get("avatar", $uid);
        $name = get("name", $uid, false);
        $pLink = get("plink", $uid, false);
        $lk = $OP->didLike($id, "cmt") === false ? "Like":"Unlike";
        $class = strtolower($lk) == "unlike" ? " unlike":"";
        $html .= "<div class='comment' id='$id'>";
          $html .= "<div class='left'>";
            $html .= "<img src='$img' class='pimg'/>";
          $html .= "</div>";
          $html .= "<div class='right'>";
            $html .= "<div class='top'>";
              $html .= "<a href='{$pLink}'>$name</a>";
              $html .= "<a class='time slink' href='" . HOST . "/source/view.php?id={$r['pid']}#$id'>{$r['time']}</a>";
              $html .= "<div class='author_cmt_box'><div class='author_cmt_panel c_c'>";
                if($uid == $who){
                  $html .= "<a class='de_cmt pointer' id='$id'>Delete {$text1}</a>";
                }
                $html .= "<a class='reply_cmt pointer' data-user='$uid' id='$pid'>Reply</a>";
              $html .= "</div></div>";
            $html .= "</div>";
            $html .= "<div class='cont'>";
              $html .= $OP->format($r['comment'], true);
            $html .= "</div>";
            $html .= "<div class='actions'>";
                $html .= "<a class='reply_cmt pointer' data-user='$uid' id='$pid'>Reply</a>";
              $html .= "</div>";
            $html .= "</div>";
          $html .= "</div>";
        $html .= "</div>";
       }
       if($postCMTcount>$sql->rowCount()){
        $html .= "<a class='load_more_comments pointer' id='$pid'>Load Previous {$text1}s</a>";
       }
      }else{
        $html .= "<h2>No Replies</h2>No one has {$text2} to this {$text3} yet.";
      }
     $html .= "</div>";
    return   $html;
  }
  
  public static function notification($id){
    global $OP;
    
    $sql = $OP->dbh->prepare("SELECT * FROM `notify` WHERE id=?");
    $sql->execute(array($id));
    while($r = $sql->fetch()){
      $fid = $r['fid'];
      $img = get("avatar", $fid);
      $name = get("fname", $fid, false);
      if(preg_match("/\-/", $r['post'])){
        list($aid, $pid) = explode("-", $r['post']);
      }
      if($r['ty'] == "cmt"){
        $amsg = "answered your question";
        $alnk = Open::URL("/source/view.php?id={$pid}#{$aid}");
      }elseif($r['ty'] == "fol"){
        $amsg = "is now following you";
        $alnk = get("plink", $r['fid']);
      }elseif($r['ty'] == "msg"){
        $amsg = "sent you a message";
        $alnk = Open::URL("/source/chat.php?id={$r['fid']}");
      }elseif($r['ty'] == "men"){
        $amsg = "mentioned you in a post";
        $alnk = Open::URL("/source/view.php?id=$pid");
      }elseif($r['ty'] == "menc"){
        $amsg = "mentioned you in a comment";
        $alnk = Open::URL("/source/view.php?id=$pid");
      }else{
        $amsg = "";
        $alnk = "";
      }
      $iuR = $r['red'] == 0 ? "nred":"";
      $iuT = $r['red'] == 0 ? "Unread Notification":"";
      $nfs="<a href='$alnk'>";
        $nfs.="<div class='nfsi $iuR' id='$id' title='$iuT'>";
          $nfs.="<div class='left'>";
            $nfs.="<img height='32' width='32' src='$img'/>";
          $nfs.="</div>";
          $nfs.="<div class='right'>";
            $nfs.="<span class='name'>$name</span>";
            $nfs.="<span class='time'>{$r['posted']}</span>";
            $nfs.="<div class='cont'>";
              $nfs .= $amsg;
            $nfs.="</div>";
          $nfs.="</div>";
        $nfs.="</div>";
      $nfs.="</a>";
    }
    $sql = $OP->dbh->prepare("UPDATE `notify` SET red='1' WHERE `id` = ?");
    $sql->execute(array($id));
    return $nfs;
  }
}
?>
