<div class="footer">
  &copy; <?php echo date("Y");?> zikafund 
  <div style="float:right;">
  	Powered by: El&rsquo;s Technologies 
  </div>  
  	<!--<q> <?php include "sitestat.php";?> </q>-->
    <center>By using zikafund, you are agreeing to our<strong><a id="T_C">Terms & Conditions.</a></strong></center>
</div>

