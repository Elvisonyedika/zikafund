<div id="sidebar" style="line-height:12px">
        <ul>
         	<?php if(loggedIn){ 
		if($who == 22 || $who == 36){?>
            <li><a href="<?php echo HOST;?>/source/admin.php">Admin</a></li>
		<?php }?>
            <li><a href="<?php echo HOST;?>">Dashboard</a></li>
            <li><a href="<?php echo HOST;?>/source/transactions.php">Transactions</a></li>
            <li><a href="<?php echo HOST;?>/source/referrals.php">Referrals</a></li>
            <li><a href="<?php echo HOST;?>/source/contact.php">Support</a></li>
            <li><a href="<?php echo HOST;?>/source/login.php?logout=true">Logout</a></li>
        	<?php } else {?>
            <li><a href="<?php echo HOST;?>">Home</a></li>
            <li><a href="<?php echo HOST;?>/source/about.php">About Us</a></li>
            <li><a href="<?php echo HOST;?>/source/contact.php">Contact Us</a></li>
            <li><a href="<?php echo HOST;?>/source/how-it-works.php">How It Works</a></li>
            <li><a href="<?php echo HOST;?>/source/login.php
				<?php
        			if( isset($_SERVER['REQUEST_URI']) ){ 
          			if( $_SERVER['REQUEST_URI'] != "/" && !preg_match("/\/login/", $_SERVER['REQUEST_URI']) ){
           			echo "?c=";
            		echo $_SERVER['REQUEST_URI'];
         			 	}
       				 }
				?>">Login</a>
        	</li>
            <li><a href="<?php echo HOST;?>/source/register.php">Register</a></li>
        </ul>
     <?php }?>
</div>
   <div class="swipe-area-left">
    </div>
    <div class="swipe-area-right">
  </div>
</div>
