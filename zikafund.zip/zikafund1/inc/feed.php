<?php
require_once "render.php";
$nemife = array(1,2,3,4,5,6,7,8,9,10,22,36);
if (in_array($who,$nemife)){
   $sql = $OP->dbh->prepare("SELECT * FROM `support_tickets` 
   ORDER BY id DESC LIMIT 5");
   $sql->execute(array());
}else{
    $sql = $OP->dbh->prepare("SELECT * FROM `support_tickets` 
   WHERE `uID`=:id ORDER BY id DESC LIMIT 5");
   $sql->execute(array(
      ":id" =>  $who
   ));
}

$postArr = $sql->fetchAll(PDO::FETCH_ASSOC);
echo Render::post($postArr);

echo "<div class='load_more_posts'><div class='normal'><center>Load More Feeds</div><div class='loader' hide><img src='". HOST ."/cdn/img/load.gif' height='32' width='32'/><span>Loading More Feeds</span></div></div>";

?>