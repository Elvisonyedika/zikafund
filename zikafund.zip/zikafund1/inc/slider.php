<div class="slideshow-container">

  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="cdn/img/img2/main.jpg" style="width:100%;  height:85%;">
    <div class="text"><h1>@Zikafund:</h1><br/>
    <h2>Get 100% (x2) of your Donations.</h2><br/>
     <h3>You don't need to do anything<br/>
     Just activate a package and earn<br/>
    </h3>Read More...</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="cdn/img/img2/main.jpg" style="width:100%; height:85%;">
    <div class="text"><h1>@Zikafund:</h1><br/>
    <h2>Kepp activating the money!</h2><br/>
    <h3>The more you activate!!<br/>
    The more you smiling to your bank!!!<br/>
    </h3>Read More...</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="cdn/img/img2/main.jpg" style="width:100%; height:85%;">
    <div class="text"><h1>@Zikafund:</h1><br/>
    <h2>Refer Someone Today</h2><br/>
    <h3>Earn N1000 bonus per referral<br/>
    (Referral is optional)<br/>
    </h3>Read More...</div>
  </div>

  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<div class="dotarea">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span>
</div>

<style>
/* Slideshow container */
.slideshow-container {
  width: 100%;
  position: relative;
  margin-top: 100px;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 2em;
  padding: 8px 12px;
  position: absolute;
  bottom:50px;
  width: 100%;
  text-align: center;
  line-height: 0px;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
  display: none;
}

/* The dots/bullets/indicators */
.dotarea {
	text-align:center; 
	background-color: white;
    height: 35px;
    margin-top: -30px;
	}
.dot {
  cursor:pointer;
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}
@media screen and (max-width: 1050px){
  .slideshow-container {
  width: 92%;
  left:4%;
  margin-top: 132px;}
  .text {
  font-size: 2.5em;
  bottom: 20%;
  text-transform: uppercase;
}
}
</style>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 10000); // Change image every 2 seconds
}
</script>