<?php 
require_once "../load.php";
\Fr\LS::init();
$pkID =isset($_GET['pkID']) ? $_GET['pkID'] : "";
if ($pkID > 0){
$list = $OP->dbh->prepare("select * from packages where id = ?");
$list->execute(array($pkID));
$r = $list->fetch();
$rInv = $r['price'] * 2;
		if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            }       	
			/*Credit user*/
			$HRep = new Ec();
			$pay = $HRep->createOrder($who, $pkID, $rInv, $rInv);
			}
//$tID =isset($_GET['t']) ? $_GET['t'] : "";
$str = isset($_GET['val']) ? $_GET['val'] : "";
$str = explode('?',$str);
$val = $str[0];
$tID = $str[1];
$tStatusID = $str[2];
if ($val === "Paid"){
header("Location: ../source/home.php");
exit;
}
$returnURL = $tStatusID == 8 ? "../source/admin.php" : "../source/home.php";
if ($val === "Decline" || $val === "Purge"){
	if ($tStatusID == 2){
		$sostID = 8;
		$tstID = 8;
		$rIndic = 0;
		}else{
	$sostID = 7;
	$tstID = 7;
	$rIndic = -1; //Derease the reciever's orderID by 1
	}
	}else{ // Val is confirm
		$sostID = 3;
		$tstID = 6;
		$rIndic = 1; //Increase the reciever's orderID by 1
		}
		$closed = date('Y-m-d H:i:s');
		$sProve = "";
		if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.ecoin.php";
            }
			/*Update transaction and order*/ 
			$HRep = new Ec();
			$upDate = $HRep->upDate($tID, $rIndic, $sostID, $tstID, $closed,$sProve);
			if ($tstID = 6){
			$upDate = $HRep->createRefBonus("", $upDate, $tstID);
			}
header("Location: ../source/home.php");
?>