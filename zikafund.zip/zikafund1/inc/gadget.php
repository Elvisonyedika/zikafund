<?php if(loggedIn){
	if(!class_exists("Ec")){
              require_once "$docRoot/inc/class.zikafund.php";
            }       	
			$HRep = new Ec();
            $HRep = $HRep->getRep($who);
?>
    <div id="sidebar" style="line-height:12px;right:1px; text-align:left;">
        <div style="text-align:center; border-bottom: 5px solid #CCCCCC; height:35px; margin-top:-15px;">
        	<h3>Account Detail</h3>
        </div>
  		<ul>
            <li><a>Name:</a></li>
            <li><a>Wallet Address:</a></li>
            <li><a>Main:  <?php echo $HRep['mainBal'];?></a></li>
            <li><a>Interest:  <?php echo $HRep['interestBal'];?></a></li>
            <li><a>Bonus:  <?php echo $HRep['bonusBal'];?></a></li>
            <li><a>Loan:  <?php echo $HRep['loanBal'];?></a></li>
            <li><a>Rank:  <?php echo $HRep['rank'];?></a></li>
            <li><a>Click here to learn how to climb to the next rank</a></li>
        </ul>
        <div style="text-align:center; border-bottom: 5px solid #CCCCCC; height:35px; margin-top:-15px;">
        	<h3>Promo Task</h3>
        </div>
        <ul>
            <li><a href="#">Referral Link:</a></li>
            <li><a href="#">Post to Social Networks</a></li>
        </ul>
   </div>

  <?php }else {?>
  <div id="sidebar" style="line-height:12px;right:1px; text-align:right;">
  		<ul>
            <li><a href="<?php echo HOST;?>/source/login.php">Login</a></li>
            <li><a href="<?php echo HOST;?>/source/register.php">Join Us</a></li>
        </ul>
        <div style="text-align:center; border-bottom: 5px solid #CCCCCC; height:35px;">
        	<h3>News / Events</h3>
        </div>
        <?php include "$docRoot/scrolltext.php";?>
   </div>
  <?php }?>
 </div>
</div>