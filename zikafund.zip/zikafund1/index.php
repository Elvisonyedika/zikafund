<?php
require_once "load.php";
//\Fr\LS::init();
if ($tl > 0){
	header ("location: prelaunch.php");
	} else if (loggedIn){
	header ("location: source/home.php");
	} else { ?>
<?php include "$docRoot/inc/styles.php";
include "$docRoot/inc/header.php"; 
include "$docRoot/inc/scripts.php";?>
<!DOCTYPE html>
<html>
	<head>
		<title>Zikafund | Keep the money flowing...</title>
	</head>
	  <?php include "$docRoot/inc/slider.php"; ?>
         <div style="background:white;color:green; margin-top:-50px;">
  			<div class="icontent">    				
				<div class="row">
                	<div class="col-md-12">
                    	<center><div class="heading text-center">
                        <h2 style="color:red;">Disclaimer!!!</h2>
                    </div>
<p>zikafund is not a bank, nor does it collect your money, It is neither a business nor an online business, HYIP (High yield investment program), investment or MLM (Multi-level marketing) program. There is no guarantees on return investments, hence we advice you use only spare cash. There is no Central zikafund Account where all the donations flow into. All the donations flow through the banking accounts of the participants themselves. Zikafund is simply a peer to peer donation system.</p>

<p>Register with us and join other zikafund participants. Your wealth is our commitment.</p>

<p style="margin-bottom:0px">Support Email: support@zikafund.com</p></center>
                 </div>
  			 </div>
 		 </div>
         <div style="background:white;color:green;">
  			<div class="icontent">
            <?php include "$docRoot/inc/packages.php";?>	
  			</div>
 		</div>
        <div style="background:white;color:green;">
 			<div class="icontent" style="margin-bottom:0px; height:0px">    				
				<div class="row">
                	<div class="col-md-12">
                    	<center><div class="heading text-center">
                        <h2>Testimonials</h2>
                        	<p class="lead">
                            	See what people are saying about us.
                            </p>
                        </center>
                        <ul class="testimonials-grid grid-3 clearfix">
                        	<li>
                            	<div class="testimonial">
                                	<div class="testi-content">
                                    	<p style="text-transform: lowercase; font-weight: normal;">I had my fears at first,
                                         but am proud to say noblepayers rocks. 
                                         i will keep on recommending them to all my pals
                                        </p>
                                        <div class="testi-meta">
											Aliyu Samson
										</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="testimonial">
                                	<div class="testi-content">
                                    	<p style="text-transform: lowercase; font-weight: normal;">I had my fears at first,
                                         but am proud to say noblepayers rocks. 
                                         i will keep on recommending them to all my pals
                                        </p>
                                        <div class="testi-meta">
											Aliyu Samson
										</div>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="testimonial">
                                	<div class="testi-content">
                                    	<p style="text-transform: lowercase; font-weight: normal;">I had my fears at first,
                                         but am proud to say noblepayers rocks. 
                                         i will keep on recommending them to all my pals
                                        </p>
                                        <div class="testi-meta">
											Aliyu Samson
										</div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
   				</div> 
  			</div>
 		</div>
<?php
include "$docRoot/inc/sidemenu.php"; 
include "$docRoot/inc/footer.php"; 
} ?>
</html>