<?php
require_once "load.php";
//\Fr\LS::init();
if ($tl < 0){
	header ("location: index.php");
	} else { ?>
<?php include "$docRoot/inc/styles.php";?>
<!DOCTYPE html>
<html>
	<head>
		<title>Zikafund | Keep the money flowing...</title>
	</head>
         <div style="background:white;color:white; background:green; min-height:100%;">
  			<div class="icontent">    				
				<center><h1>ZIKAFUND NIGERIA WILL BE LAUNCHED ON SUNDAY BY 6PM</h1></center>
                	<div class="icontent">
                	<div id="tl">

                    </div>
                    </div>
                    <div class="icontent">
                	<center><p>
                    	zikafund was founded with the sole aim of providing a user friendly online financial
                 	community for the purpose of empowering individuals and achievement of their financial
                  	goals and targets in business and general financial flexibility. Zika fund is an 
                  	automated system that gives its members 100% return on investment to eneble members 
                  	achieve their goals, dreams, and aspirations.
                	</p></center>
                    </div>
  			</div>
 		</div>
<?php 
include "$docRoot/inc/scripts.php"; 
} ?>


<style>
	#tl {
	position:relative; 
	border: 2px solid white; 
    height:100px; 
	width:50%; 
	text-align:center; 
	left:25%; 
	padding-top:30px; 
    font-size:40px; 
	margin-top:40px;	
		}
@media screen and (max-width: 1050px){
	#tl {width:100%;
	left:0;
	font-size:55px;
	height:150px;
	padding-top:50px; 
	}
	
	.icontent {
    padding-top: 5%;
}
h1 { font-size:80px;}
}
</style>


<script>
var e = '<?php echo $TBL;?>';
var end = new Date(e);

    var _second = 1000;
    var _minute = _second * 60;
    var _hour = _minute * 60;
    var _day = _hour * 24;
    var timer;

    function showRemaining() {
        var now = new Date();
        var distance = end - now;
        if (distance < 0) {

            clearInterval(timer);
            document.getElementById('countdown').innerHTML = 'EXPIRED!';

            return;
        }
        var days = Math.floor(distance / _day);
        var hours = Math.floor((distance % _day) / _hour);
        var minutes = Math.floor((distance % _hour) / _minute);
        var seconds = Math.floor((distance % _minute) / _second);
		var tl = days + 'days :' + hours + 'hrs :' + minutes + 'mins :' + seconds + 'secs';

        document.getElementById('tl').innerHTML = tl;
    }

    timer = setInterval(showRemaining, 1000);
</script>

</html>